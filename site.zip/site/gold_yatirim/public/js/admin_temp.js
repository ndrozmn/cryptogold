document.addEventListener('DOMContentLoaded', () => {
  const searchInput = document.getElementById('searchInput');
  const usersContainer = document.getElementById('userListBody');
  const investmentRequests = document.getElementById('investmentRequests');
  const withdrawalRequests = document.getElementById('withdrawalRequests');
  const investmentEditFormContainer = document.getElementById('investmentEditFormContainer');
  const editInvestmentId = document.getElementById('editInvestmentId');
  const editStockControl = document.getElementById('editStockControl');
  const editPrice = document.getElementById('editPrice');
  const editEarnings = document.getElementById('editEarnings');
  const editPercentage = document.getElementById('editPercentage');
  const cancelEditInvestment = document.getElementById('cancelEditInvestment');
  const investmentEditForm = document.getElementById('investmentEditForm');

  async function deleteUser(userId) {
    try {
      const res = await fetch(`/admin/users/${userId}`, { method: 'DELETE' });
      if (res.ok) {
        alert('Kullanıcı silindi');
        loadUsers();
      } else {
        alert('Kullanıcı silinirken hata oluştu');
      }
    } catch (error) {
      console.error('Kullanıcı silme hatası:', error);
    }
  }

  async function resetPassword(userId) {
    try {
      const res = await fetch(`/admin/users/${userId}/reset-password`, { method: 'POST' });
      if (res.ok) {
        alert('Şifre sıfırlama işlemi başarılı');
      } else {
        alert('Şifre sıfırlama işlemi başarısız');
      }
    } catch (error) {
      console.error('Şifre sıfırlama hatası:', error);
    }
  }

  async function loadUsers() {
    try {
      const res = await fetch('/admin/users');
      const users = await res.json();
      displayUsers(users);
    } catch (error) {
      console.error('Kullanıcılar yüklenirken hata:', error);
    }
  }

  function displayUsers(users) {
    usersContainer.innerHTML = '';
    users.forEach(user => {
      const tr = document.createElement('tr');

      const tdUsername = document.createElement('td');
      tdUsername.textContent = user.username;
      tr.appendChild(tdUsername);

      const tdEmail = document.createElement('td');
      tdEmail.textContent = user.email;
      tr.appendChild(tdEmail);

      const tdBalance = document.createElement('td');
      tdBalance.textContent = user.balance !== undefined ? user.balance : '-';
      tr.appendChild(tdBalance);

      const tdActions = document.createElement('td');

      const deleteBtn = document.createElement('button');
      deleteBtn.textContent = 'Sil';
      deleteBtn.style.marginRight = '10px';
      deleteBtn.addEventListener('click', () => deleteUser(user._id));
      tdActions.appendChild(deleteBtn);

      const resetBtn = document.createElement('button');
      resetBtn.textContent = 'Şifre Sıfırla';
      resetBtn.addEventListener('click', () => resetPassword(user._id));
      tdActions.appendChild(resetBtn);

      tr.appendChild(tdActions);

      usersContainer.appendChild(tr);
    });
  }

  async function loadInvestmentRequests() {
    try {
      const res = await fetch('/admin/investment-requests');
      const requests = await res.json();
      displayInvestmentRequests(requests);
    } catch (error) {
      console.error('Yatırım talepleri yüklenirken hata:', error);
    }
  }

  function displayInvestmentRequests(requests) {
    investmentRequests.innerHTML = '';
    requests.forEach(req => {
      const div = document.createElement('div');
      div.textContent = `Yatırım Talebi: ${req._id} - Miktar: ${req.amount}`;

      const editBtn = document.createElement('button');
      editBtn.textContent = 'Düzenle';
      editBtn.style.marginLeft = '10px';
      editBtn.addEventListener('click', () => {
        openEditInvestmentForm(req);
      });
      div.appendChild(editBtn);

      investmentRequests.appendChild(div);
    });
  }

  function openEditInvestmentForm(investment) {
    investmentEditFormContainer.style.display = 'block';
    editInvestmentId.value = investment._id;
    editStockControl.value = investment.stockControl || 0;
    editPrice.value = investment.price || 0;
    editEarnings.value = investment.earnings || 0;
    editPercentage.value = investment.percentage || 0;
    showSection('sectionInvestmentRequests');
  }

  cancelEditInvestment.addEventListener('click', () => {
    investmentEditFormContainer.style.display = 'none';
  });

  investmentEditForm.addEventListener('submit', async (e) => {
    e.preventDefault();
    const investmentId = editInvestmentId.value;
    const data = {
      stockControl: parseInt(editStockControl.value, 10),
      price: parseFloat(editPrice.value),
      earnings: parseFloat(editEarnings.value),
      percentage: parseFloat(editPercentage.value),
    };
    try {
      const res = await fetch(`/admin/investment-requests/${investmentId}/update`, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(data),
      });
      if (res.ok) {
        alert('Yatırım ayarları güncellendi');
        investmentEditFormContainer.style.display = 'none';
        loadInvestmentRequests();
      } else {
        alert('Yatırım ayarları güncellenirken hata oluştu');
      }
    } catch (error) {
      console.error('Yatırım ayarları güncelleme hatası:', error);
    }
  });

  async function loadWithdrawalRequests() {
    try {
      const res = await fetch('/admin/withdrawal-requests');
      const requests = await res.json();
      displayWithdrawalRequests(requests);
    } catch (error) {
      console.error('Çekim talepleri yüklenirken hata:', error);
    }
  }

  function displayWithdrawalRequests(requests) {
    withdrawalRequests.innerHTML = '';
    requests.forEach(req => {
      const div = document.createElement('div');
      div.textContent = `Çekim Talebi: ${req._id} - Miktar: ${req.amount}`;
      withdrawalRequests.appendChild(div);
    });
  }

  searchInput.addEventListener('input', async () => {
    const query = searchInput.value.toLowerCase();
    try {
      const res = await fetch('/admin/users');
      const users = await res.json();
      const filtered = users.filter(user =>
        user.username.toLowerCase().includes(query) ||
        user.email.toLowerCase().includes(query)
      );
      displayUsers(filtered);
    } catch (error) {
      console.error('Arama sırasında hata:', error);
    }
  });

  function showSection(sectionId) {
    const sections = document.querySelectorAll('.admin-section');
    sections.forEach(sec => {
      sec.style.display = 'none';
    });
    const target = document.getElementById(sectionId);
    if (target) target.style.display = 'block';
  }

  loadUsers();
  loadInvestmentRequests();
  loadWithdrawalRequests();
  showSection('sectionUsers');
});
