document.addEventListener('DOMContentLoaded', () => {
  // DOM Elemanları
  const investmentSettingsTable = document.getElementById('investmentSettingsTable').getElementsByTagName('tbody')[0];
  const investmentEditFormContainer = document.getElementById('investmentEditFormContainer');
  const editInvestmentId = document.getElementById('editInvestmentId');
  const editStockControl = document.getElementById('editStockControl');
  const editPrice = document.getElementById('editPrice');
  const editEarnings = document.getElementById('editEarnings');
  const editPercentage = document.getElementById('editPercentage');
  const cancelEditInvestment = document.getElementById('cancelEditInvestment');
  const investmentEditForm = document.getElementById('investmentEditForm');
  
  // Yatırım seçeneklerini yükle
  async function loadInvestmentOptions() {
    try {
      const res = await fetch('/admin/investment-options');
      if (!res.ok) {
        throw new Error('Yatırım seçenekleri yüklenemedi');
      }
      const options = await res.json();
      displayInvestmentOptions(options);
    } catch (error) {
      console.error('Yatırım seçenekleri yüklenirken hata:', error);
      investmentSettingsTable.innerHTML = '<tr><td colspan="6">Yatırım seçenekleri yüklenirken hata oluştu.</td></tr>';
    }
  }

  // Yatırım seçeneklerini tabloya ekle
  function displayInvestmentOptions(options) {
    investmentSettingsTable.innerHTML = '';
    
    if (options.length === 0) {
      const tr = document.createElement('tr');
      const td = document.createElement('td');
      td.colSpan = 6;
      td.textContent = 'Yatırım seçeneği bulunmamaktadır.';
      td.style.textAlign = 'center';
      tr.appendChild(td);
      investmentSettingsTable.appendChild(tr);
      return;
    }
    
    options.forEach(option => {
      const tr = document.createElement('tr');
      
      // Yatırım adı
      const nameTd = document.createElement('td');
      nameTd.textContent = option.name || `Altın Paket ${option.id}`;
      tr.appendChild(nameTd);
      
      // Fiyat
      const priceTd = document.createElement('td');
      priceTd.textContent = option.price || '0';
      tr.appendChild(priceTd);
      
      // Kilitleme süreleri
      const lockDaysTd = document.createElement('td');
      lockDaysTd.innerHTML = '7, 14, 21, 32 gün';
      tr.appendChild(lockDaysTd);
      
      // Komisyon oranları
      const interestRateTd = document.createElement('td');
      interestRateTd.innerHTML = '7%, 13%, 20%, 30%';
      tr.appendChild(interestRateTd);
      
      // Stok kontrolü
      const stockControlTd = document.createElement('td');
      stockControlTd.textContent = option.stockControl || '10';
      tr.appendChild(stockControlTd);
      
      // İşlemler
      const actionsTd = document.createElement('td');
      
      // Düzenle butonu
      const editBtn = document.createElement('button');
      editBtn.textContent = 'Düzenle';
      editBtn.addEventListener('click', () => {
        openEditInvestmentForm(option);
      });
      actionsTd.appendChild(editBtn);
      
      tr.appendChild(actionsTd);
      investmentSettingsTable.appendChild(tr);
    });
  }

  // Düzenleme formunu aç
  function openEditInvestmentForm(option) {
    investmentEditFormContainer.style.display = 'block';
    editInvestmentId.value = option.id;
    editStockControl.value = option.stockControl || 10;
    editPrice.value = option.price || 0;
    editEarnings.value = option.earnings || 0;
    editPercentage.value = option.percentage || 7;
  }

  // Düzenleme formunu kapat
  cancelEditInvestment.addEventListener('click', () => {
    investmentEditFormContainer.style.display = 'none';
  });

  // Düzenleme formu gönderimi
  investmentEditForm.addEventListener('submit', async (e) => {
    e.preventDefault();
    const investmentId = editInvestmentId.value;
    const data = {
      stockControl: parseInt(editStockControl.value, 10),
      price: parseFloat(editPrice.value),
      earnings: parseFloat(editEarnings.value),
      percentage: parseFloat(editPercentage.value),
    };
    try {
      const res = await fetch(`/admin/investment-options/${investmentId}/update`, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(data),
      });
      if (res.ok) {
        alert('Yatırım seçeneği güncellendi');
        investmentEditFormContainer.style.display = 'none';
        loadInvestmentOptions();
      } else {
        alert('Yatırım seçeneği güncellenirken hata oluştu');
      }
    } catch (error) {
      console.error('Yatırım seçeneği güncelleme hatası:', error);
      alert('Yatırım seçeneği güncellenirken hata oluştu');
    }
  });

  // Sayfa yüklendiğinde yatırım seçeneklerini yükle
  loadInvestmentOptions();
});
