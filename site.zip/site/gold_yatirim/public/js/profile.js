document.addEventListener('DOMContentLoaded', () => {
  const balanceElement = document.getElementById('balance');
  const referralCodeElement = document.getElementById('referral-code');
  const referralEarningsElement = document.getElementById('referral-earnings');
  const activeInvestmentsList = document.getElementById('active-investments-list');
  const pastInvestmentsList = document.getElementById('past-investments-list');
  const depositBtn = document.getElementById('deposit-btn');
  const withdrawBtn = document.getElementById('withdraw-btn');
  const saveTronWalletBtn = document.getElementById('save-tron-wallet-btn');
  const tronWalletInput = document.getElementById('tron-wallet-input');
  
  let currentDepositId = null;
  let tronWalletAddress = '';

  // TRON cüzdan adresi kaydetme butonuna tıklama
  saveTronWalletBtn.addEventListener('click', () => {
    const walletAddress = tronWalletInput.value.trim();
    if (!walletAddress) {
      alert('Lütfen geçerli bir TRON cüzdan adresi girin.');
      return;
    }
    
    fetch('/profile/save-tron-wallet', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ tronWalletAddress: walletAddress }),
    })
      .then(res => res.json())
      .then(data => {
        if (data.error) {
          alert(data.error);
        } else {
          alert(data.message);
          tronWalletAddress = data.tronWalletAddress;
          tronWalletInput.value = tronWalletAddress;
        }
      })
      .catch(() => alert('TRON cüzdan adresi kaydedilemedi.'));
  });

  // Para yatırma modal'ını oluştur
  const depositModal = document.createElement('div');
  depositModal.className = 'modal';
  depositModal.id = 'depositModal';
  depositModal.innerHTML = `
    <div class="modal-content">
      <span class="close-button">&times;</span>
      <h2>Para Yatırma</h2>
      <div class="deposit-form">
        <div class="form-group">
          <label for="deposit-amount">Yatırmak istediğiniz miktar (USDT):</label>
          <input type="number" id="deposit-amount" min="1" step="1">
        </div>
        <div class="tron-address-container" style="display:none;">
          <p>Lütfen aşağıdaki TRON adresine belirtilen miktarı gönderin:</p>
          <div class="copy-address-container">
            <input type="text" id="tron-deposit-address" value="TKrwDVK473FNRGFPVNEFg68fNywZna6CZF" readonly>
            <button id="copy-tron-address-btn">Kopyala</button>
          </div>
          <div class="form-group">
            <label for="tron-transaction-id">TRON İşlem ID'si:</label>
            <input type="text" id="tron-transaction-id" placeholder="İşlem tamamlandıktan sonra TRON işlem ID'sini girin">
          </div>
          <button id="confirm-deposit-btn">İşlemi Onayla</button>
        </div>
        <button id="submit-deposit-btn">Para Yatır</button>
      </div>
    </div>
  `;
  document.body.appendChild(depositModal);
  
  // Modal elemanlarını seç
  const closeButton = depositModal.querySelector('.close-button');
  const depositAmountInput = document.getElementById('deposit-amount');
  const tronAddressContainer = depositModal.querySelector('.tron-address-container');
  const tronDepositAddress = document.getElementById('tron-deposit-address');
  const copyTronAddressBtn = document.getElementById('copy-tron-address-btn');
  const tronTransactionIdInput = document.getElementById('tron-transaction-id');
  const submitDepositBtn = document.getElementById('submit-deposit-btn');
  const confirmDepositBtn = document.getElementById('confirm-deposit-btn');
  
  // Modal'ı kapat
  closeButton.addEventListener('click', () => {
    depositModal.style.display = 'none';
    // Form'u sıfırla
    depositAmountInput.value = '';
    tronAddressContainer.style.display = 'none';
    tronTransactionIdInput.value = '';
    submitDepositBtn.style.display = 'block';
  });
  
  // Modal dışına tıklayınca kapat
  window.addEventListener('click', (event) => {
    if (event.target === depositModal) {
      depositModal.style.display = 'none';
    }
  });
  
  // TRON adresini kopyala
  copyTronAddressBtn.addEventListener('click', () => {
    navigator.clipboard.writeText(tronDepositAddress.value)
      .then(() => {
        alert('TRON adresi kopyalandı!');
      })
      .catch(() => {
        alert('Kopyalama işlemi başarısız oldu.');
      });
  });
  
  // Para yatırma butonuna tıklama
  depositBtn.addEventListener('click', () => {
    depositModal.style.display = 'block';
  });
  
  // Para yatırma formunu gönder
  submitDepositBtn.addEventListener('click', () => {
    const amount = depositAmountInput.value;
    if (amount && !isNaN(amount) && Number(amount) > 0) {
      fetch('/profile/create-deposit', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ amount: Number(amount) }),
      })
        .then(res => res.json())
        .then(data => {
          if (data.error) {
            alert(data.error);
          } else {
            currentDepositId = data.depositId;
            // TRON adres bölümünü göster, para yatır butonunu gizle
            tronAddressContainer.style.display = 'block';
            submitDepositBtn.style.display = 'none';
          }
        })
        .catch(() => alert('Para yatırma talebi oluşturulamadı.'));
    } else {
      alert('Geçerli bir miktar girin.');
    }
  });
  
  // Para yatırma işlemini onayla
  confirmDepositBtn.addEventListener('click', () => {
    const transactionId = tronTransactionIdInput.value.trim();
    if (!transactionId) {
      alert('Lütfen TRON işlem ID\'sini girin.');
      return;
    }
    
    confirmDeposit(currentDepositId, transactionId);
    depositModal.style.display = 'none';
  });

  // Para yatırma talebini onaylama
  function confirmDeposit(depositId, transactionId) {
    fetch('/profile/confirm-deposit', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ 
        depositId, 
        tronTransactionId: transactionId 
      }),
    })
      .then(res => res.json())
      .then(data => {
        if (data.error) {
          alert(data.error);
        } else {
          alert('Para yatırma talebiniz alındı. İşleminiz en kısa sürede incelenecektir.');
        }
      })
      .catch(() => alert('Para yatırma talebi onaylanamadı.'));
  }

  // Para çekme butonuna tıklama
  withdrawBtn.addEventListener('click', () => {
    if (!tronWalletAddress) {
      alert('Para çekmek için önce TRON cüzdan adresinizi kaydetmelisiniz.');
      return;
    }
    
    const amount = prompt('Çekmek istediğiniz miktarı girin (USDT):');
    if (amount && !isNaN(amount) && Number(amount) > 0) {
      const amountNum = Number(amount);
      const fee = amountNum * 0.05;
      const netAmount = amountNum - fee;
      
      const confirmMessage = `
        Çekim Detayları:
        - Miktar: ${amountNum} USDT
        - Komisyon (%5): ${fee.toFixed(2)} USDT
        - Net Miktar: ${netAmount.toFixed(2)} USDT
        - TRON Cüzdan Adresi: ${tronWalletAddress}
        
        Onaylıyor musunuz?
      `;
      
      if (confirm(confirmMessage)) {
        fetch('/profile/create-withdrawal', {
          method: 'POST',
          headers: { 'Content-Type': 'application/json' },
          body: JSON.stringify({ 
            amount: amountNum,
            tronWalletAddress 
          }),
        })
          .then(res => res.json())
          .then(data => {
            if (data.error) {
              alert(data.error);
            } else {
              alert('Para çekme talebiniz alındı. İşleminiz en kısa sürede incelenecektir.');
              balanceElement.textContent = data.balance;
            }
          })
          .catch(() => alert('Para çekme talebi oluşturulamadı.'));
      }
    } else {
      alert('Geçerli bir miktar girin.');
    }
  });

  // Davet edilen kullanıcılar modal'ını oluştur
  const referredUsersModal = document.createElement('div');
  referredUsersModal.className = 'modal';
  referredUsersModal.id = 'referredUsersModal';
  referredUsersModal.innerHTML = `
    <div class="modal-content">
      <span class="close-button">&times;</span>
      <h2>Davet Ettiğim Kullanıcılar</h2>
      <div class="referred-users-modal-list" id="referred-users-modal-list">
        <p>Yükleniyor...</p>
      </div>
    </div>
  `;
  document.body.appendChild(referredUsersModal);
  
  // Modal elemanlarını seç
  const referredUsersCloseButton = referredUsersModal.querySelector('.close-button');
  const referredUsersModalList = document.getElementById('referred-users-modal-list');
  const showReferredUsersBtn = document.getElementById('show-referred-users-btn');
  
  // Modal'ı kapat
  referredUsersCloseButton.addEventListener('click', () => {
    referredUsersModal.style.display = 'none';
  });
  
  // Modal dışına tıklayınca kapat
  window.addEventListener('click', (event) => {
    if (event.target === referredUsersModal) {
      referredUsersModal.style.display = 'none';
    }
  });
  
  // Davet ettiğim kullanıcılar butonuna tıklama
  showReferredUsersBtn.addEventListener('click', () => {
    referredUsersModal.style.display = 'block';
    loadReferredUsers();
  });

  // İşlem geçmişi sekmelerini yönet
  const transactionTabs = document.querySelectorAll('.transaction-tab');
  const transactionContents = document.querySelectorAll('.transaction-content');
  
  transactionTabs.forEach(tab => {
    tab.addEventListener('click', () => {
      // Aktif sekmeyi değiştir
      transactionTabs.forEach(t => t.classList.remove('active'));
      tab.classList.add('active');
      
      // İlgili içeriği göster
      const tabName = tab.dataset.tab;
      transactionContents.forEach(content => {
        content.classList.remove('active');
      });
      document.getElementById(`${tabName}-content`).classList.add('active');
      
      // İçeriği yükle
      if (tabName === 'deposits') {
        loadDeposits();
      } else if (tabName === 'withdrawals') {
        loadWithdrawals();
      } else if (tabName === 'pending') {
        loadPendingTransactions();
      }
    });
  });
  
  // Para yatırma işlemlerini yükle
  function loadDeposits() {
    const depositsList = document.getElementById('deposits-list');
    depositsList.innerHTML = '<p>Yükleniyor...</p>';
    
    fetch('/profile/deposits')
      .then(res => res.json())
      .then(data => {
        if (data.deposits && data.deposits.length > 0) {
          depositsList.innerHTML = '<ul class="transaction-list">' + 
            data.deposits.map(deposit => 
              `<li class="transaction-item">
                <div class="transaction-header">
                  <span class="transaction-amount">${deposit.amount} USDT</span>
                  <span class="status ${deposit.status}">${getStatusText(deposit.status)}</span>
                </div>
                <div class="transaction-details">
                  <p>Tarih: ${new Date(deposit.createdAt).toLocaleDateString()}</p>
                  <p>İşlem ID: ${deposit.tronTransactionId || 'Belirtilmemiş'}</p>
                  ${deposit.processedAt ? `<p>İşlem Tarihi: ${new Date(deposit.processedAt).toLocaleDateString()}</p>` : ''}
                  ${deposit.notes ? `<p>Not: ${deposit.notes}</p>` : ''}
                </div>
              </li>`
            ).join('') + '</ul>';
        } else {
          depositsList.innerHTML = '<p>Henüz para yatırma işleminiz bulunmamaktadır.</p>';
        }
      })
      .catch((error) => {
        console.error('Para yatırma işlemleri yüklenirken hata:', error);
        depositsList.innerHTML = '<p>Para yatırma işlemleri yüklenirken hata oluştu.</p>';
      });
  }
  
  // Para çekme işlemlerini yükle
  function loadWithdrawals() {
    const withdrawalsList = document.getElementById('withdrawals-list');
    withdrawalsList.innerHTML = '<p>Yükleniyor...</p>';
    
    fetch('/profile/withdrawals')
      .then(res => res.json())
      .then(data => {
        if (data.withdrawals && data.withdrawals.length > 0) {
          withdrawalsList.innerHTML = '<ul class="transaction-list">' + 
            data.withdrawals.map(withdrawal => 
              `<li class="transaction-item">
                <div class="transaction-header">
                  <span class="transaction-amount">${withdrawal.amount} USDT</span>
                  <span class="status ${withdrawal.status}">${getStatusText(withdrawal.status)}</span>
                </div>
                <div class="transaction-details">
                  <p>Tarih: ${new Date(withdrawal.createdAt).toLocaleDateString()}</p>
                  <p>TRON Adresi: ${withdrawal.tronWalletAddress || 'Belirtilmemiş'}</p>
                  <p>Net Miktar: ${(withdrawal.amount * 0.95).toFixed(2)} USDT (Komisyon: ${(withdrawal.amount * 0.05).toFixed(2)} USDT)</p>
                  ${withdrawal.processedAt ? `<p>İşlem Tarihi: ${new Date(withdrawal.processedAt).toLocaleDateString()}</p>` : ''}
                </div>
              </li>`
            ).join('') + '</ul>';
        } else {
          withdrawalsList.innerHTML = '<p>Henüz para çekme işleminiz bulunmamaktadır.</p>';
        }
      })
      .catch((error) => {
        console.error('Para çekme işlemleri yüklenirken hata:', error);
        withdrawalsList.innerHTML = '<p>Para çekme işlemleri yüklenirken hata oluştu.</p>';
      });
  }
  
  // Bekleyen işlemleri yükle
  function loadPendingTransactions() {
    const pendingList = document.getElementById('pending-list');
    pendingList.innerHTML = '<p>Yükleniyor...</p>';
    
    fetch('/profile/pending-transactions')
      .then(res => res.json())
      .then(data => {
        const pendingDeposits = data.pendingDeposits || [];
        const pendingWithdrawals = data.pendingWithdrawals || [];
        const pendingInvestments = data.pendingInvestments || [];
        
        if (pendingDeposits.length > 0 || pendingWithdrawals.length > 0 || pendingInvestments.length > 0) {
          let html = '<ul class="transaction-list">';
          
          pendingDeposits.forEach(deposit => {
            html += `
              <li class="transaction-item">
                <div class="transaction-header">
                  <span class="transaction-type">Para Yatırma</span>
                  <span class="transaction-amount">${deposit.amount} USDT</span>
                  <span class="status pending">İşleminiz İnceleniyor</span>
                </div>
                <div class="transaction-details">
                  <p>Tarih: ${new Date(deposit.createdAt).toLocaleDateString()}</p>
                  <p>İşlem ID: ${deposit.tronTransactionId || 'Belirtilmemiş'}</p>
                </div>
              </li>
            `;
          });
          
          pendingWithdrawals.forEach(withdrawal => {
            html += `
              <li class="transaction-item">
                <div class="transaction-header">
                  <span class="transaction-type">Para Çekme</span>
                  <span class="transaction-amount">${withdrawal.amount} USDT</span>
                  <span class="status pending">İşleminiz İnceleniyor</span>
                </div>
                <div class="transaction-details">
                  <p>Tarih: ${new Date(withdrawal.createdAt).toLocaleDateString()}</p>
                  <p>TRON Adresi: ${withdrawal.tronWalletAddress || 'Belirtilmemiş'}</p>
                  <p>Net Miktar: ${(withdrawal.amount * 0.95).toFixed(2)} USDT</p>
                </div>
              </li>
            `;
          });
          
          pendingInvestments.forEach(investment => {
            html += `
              <li class="transaction-item">
                <div class="transaction-header">
                  <span class="transaction-type">Yatırım</span>
                  <span class="transaction-amount">${investment.usdtAmount} USDT</span>
                  <span class="status pending">İşleminiz İnceleniyor</span>
                </div>
                <div class="transaction-details">
                  <p>Tarih: ${new Date(investment.createdAt).toLocaleDateString()}</p>
                  <p>Kilitleme Süresi: ${investment.lockDays} gün</p>
                  <p>Faiz Oranı: ${investment.interestRate || investment.percentage}%</p>
                </div>
              </li>
            `;
          });
          
          html += '</ul>';
          pendingList.innerHTML = html;
        } else {
          pendingList.innerHTML = '<p>Bekleyen işleminiz bulunmamaktadır.</p>';
        }
      })
      .catch((error) => {
        console.error('Bekleyen işlemler yüklenirken hata:', error);
        pendingList.innerHTML = '<p>Bekleyen işlemler yüklenirken hata oluştu.</p>';
      });
  }
  
  // Durum metni döndür
  function getStatusText(status) {
    switch (status) {
      case 'pending': return 'İşleminiz İnceleniyor';
      case 'approved': return 'Onaylandı';
      case 'rejected': return 'Reddedildi';
      default: return status;
    }
  }
  
  // Sayfa yüklendiğinde yatırımları ve davet bilgilerini güncelle
  function updateProfileData() {
    fetch('/profile/data')
      .then(res => res.json())
      .then(data => {
        // Bakiye ve davet bilgilerini güncelle
        balanceElement.textContent = data.balance || 0;
        referralCodeElement.textContent = data.referralCode || 'YOK';
        referralEarningsElement.textContent = data.referralEarnings || 0;
        
        // TRON cüzdan adresini güncelle
        if (data.tronWalletAddress) {
          tronWalletAddress = data.tronWalletAddress;
          tronWalletInput.value = tronWalletAddress;
        }

        // Aktif yatırımları göster
        if (data.activeInvestments && data.activeInvestments.length > 0) {
          activeInvestmentsList.innerHTML = '<ul class="investments-list">' + 
            data.activeInvestments.map(inv => 
              `<li class="investment-item">
                <div class="investment-header">
                  <span class="investment-amount">${inv.usdtAmount} USDT</span>
                  <span class="investment-status active">Aktif</span>
                </div>
                <div class="investment-details">
                  <p>Kilitleme Süresi: ${inv.lockDays} gün</p>
                  <p>Faiz Oranı: ${inv.interestRate || inv.percentage}%</p>
                  <p>Başlangıç: ${new Date(inv.startDate).toLocaleDateString()}</p>
                  <p>Bitiş: ${new Date(inv.endDate).toLocaleDateString()}</p>
                  <p>Beklenen Kazanç: ${(inv.usdtAmount * (inv.interestRate || inv.percentage) / 100).toFixed(2)} USDT</p>
                  <p class="countdown" data-end="${new Date(inv.endDate).getTime()}">
                    Kalan Süre: <span>Hesaplanıyor...</span>
                  </p>
                </div>
              </li>`
            ).join('') + '</ul>';
        } else {
          activeInvestmentsList.innerHTML = '<p>Aktif yatırımınız bulunmamaktadır.</p>';
        }
        
        // Geçmiş yatırımları göster
        if (data.pastInvestments && data.pastInvestments.length > 0) {
          pastInvestmentsList.innerHTML = '<ul class="investments-list">' + 
            data.pastInvestments.map(inv => 
              `<li class="investment-item">
                <div class="investment-header">
                  <span class="investment-amount">${inv.usdtAmount} USDT</span>
                  <span class="investment-status completed">Tamamlandı</span>
                </div>
                <div class="investment-details">
                  <p>Kilitleme Süresi: ${inv.lockDays} gün</p>
                  <p>Faiz Oranı: ${inv.interestRate || inv.percentage}%</p>
                  <p>Başlangıç: ${new Date(inv.startDate).toLocaleDateString()}</p>
                  <p>Bitiş: ${new Date(inv.endDate).toLocaleDateString()}</p>
                  <p>Kazanç: ${(inv.usdtAmount * (inv.interestRate || inv.percentage) / 100).toFixed(2)} USDT</p>
                </div>
              </li>`
            ).join('') + '</ul>';
        } else {
          pastInvestmentsList.innerHTML = '<p>Geçmiş yatırımınız bulunmamaktadır.</p>';
        }
      })
      .catch((error) => {
        console.error('Profil verileri yüklenirken hata:', error);
        activeInvestmentsList.innerHTML = '<p>Yatırımlar yüklenirken hata oluştu.</p>';
        pastInvestmentsList.innerHTML = '';
      });
  }
  
  // Davet edilen kullanıcıları yükle
  function loadReferredUsers() {
    fetch('/profile/referred-users')
      .then(res => res.json())
      .then(data => {
        if (data.referredUsers && data.referredUsers.length > 0) {
          referredUsersModalList.innerHTML = '<ul class="referred-users-list">' + 
            data.referredUsers.map(user => 
              `<li class="referred-user-item">
                <p>Kullanıcı: ${user.username}</p>
                <p>Email: ${user.email || 'Belirtilmemiş'}</p>
                <p>Katılım: ${new Date(user.createdAt).toLocaleDateString()}</p>
                <p>Yatırım Yaptı: ${user.hasInvested ? 'Evet' : 'Hayır'}</p>
                <p>Kazandırdığı: ${user.referralEarning || 0} USDT</p>
              </li>`
            ).join('') + '</ul>';
        } else {
          referredUsersModalList.innerHTML = '<p>Henüz davet ettiğiniz kullanıcı bulunmamaktadır.</p>';
        }
      })
      .catch((error) => {
        console.error('Davet edilen kullanıcılar yüklenirken hata:', error);
        referredUsersModalList.innerHTML = '<p>Davet edilen kullanıcılar yüklenirken hata oluştu.</p>';
      });
  }

  // Geri sayım zamanlayıcısını güncelleme fonksiyonu
  function updateCountdowns() {
    const countdownElements = document.querySelectorAll('.countdown');
    
    countdownElements.forEach(element => {
      const endTime = parseInt(element.dataset.end, 10);
      const now = new Date().getTime();
      const timeLeft = endTime - now;
      
      const countdownSpan = element.querySelector('span');
      
      if (timeLeft <= 0) {
        countdownSpan.textContent = 'Süre doldu! Yenileniyor...';
        // Süre dolduğunda sayfayı yenile (yatırım durumunu güncellemek için)
        setTimeout(() => {
          location.reload();
        }, 3000);
      } else {
        // Gün, saat, dakika, saniye hesaplama
        const days = Math.floor(timeLeft / (1000 * 60 * 60 * 24));
        const hours = Math.floor((timeLeft % (1000 * 60 * 60 * 24)) / (1000 * 60 * 60));
        const minutes = Math.floor((timeLeft % (1000 * 60 * 60)) / (1000 * 60));
        const seconds = Math.floor((timeLeft % (1000 * 60)) / 1000);
        
        countdownSpan.textContent = `${days} gün ${hours} saat ${minutes} dk ${seconds} sn`;
      }
    });
  }
  
  // Sayfa yüklendiğinde verileri güncelle
  updateProfileData();
  
  // İşlem geçmişi sekmelerini yükle
  loadDeposits();
  
  // Geri sayım zamanlayıcısını başlat
  setInterval(updateCountdowns, 1000);

  // Davet Kazan butonuna tıklama
  const generateReferralLinkBtn = document.getElementById('generate-referral-link-btn');
  const referralLinkMessage = document.getElementById('referral-link-message');

  generateReferralLinkBtn.addEventListener('click', () => {
    fetch('/profile/referral-link')
      .then(res => res.json())
      .then(data => {
        if (data.referralLink) {
          referralLinkMessage.style.display = 'none';
          referralLinkContainer.style.display = 'block';
          referralLinkInput.value = data.referralLink;
        } else {
          referralLinkMessage.style.display = 'block';
          referralLinkMessage.style.color = 'red';
          referralLinkMessage.textContent = 'Davet bağlantısı oluşturulamadı.';
          referralLinkContainer.style.display = 'none';
        }
      })
      .catch(() => {
        referralLinkMessage.style.display = 'block';
        referralLinkMessage.style.color = 'red';
        referralLinkMessage.textContent = 'Davet bağlantısı oluşturulurken hata oluştu.';
        referralLinkContainer.style.display = 'none';
      });
  });

  // Kopyala butonuna tıklama
  const referralLinkContainer = document.getElementById('referral-link-container');
  const referralLinkInput = document.getElementById('referral-link-input');
  const copyReferralLinkBtn = document.getElementById('copy-referral-link-btn');
  copyReferralLinkBtn.addEventListener('click', () => {
    const link = referralLinkInput.value;
    if (link) {
      navigator.clipboard.writeText(link).then(() => {
        alert('Davet bağlantısı kopyalandı!');
      }).catch(() => {
        alert('Kopyalama işlemi başarısız oldu.');
      });
    }
  });
});
