document.addEventListener('DOMContentLoaded', () => {
  // Theme switcher functionality
  const createThemeSwitcher = () => {
    // Create theme switcher button
    const themeSwitcher = document.createElement('button');
    themeSwitcher.id = 'theme-switcher';
    themeSwitcher.innerHTML = '🌓';
    themeSwitcher.setAttribute('aria-label', 'Tema Değiştir');
    themeSwitcher.style.cssText = `
      position: fixed;
      bottom: 80px;
      right: 20px;
      background-color: #0f0f3f;
      color: #00ffe5;
      border: none;
      border-radius: 50%;
      width: 50px;
      height: 50px;
      font-size: 24px;
      cursor: pointer;
      z-index: 99;
      box-shadow: 0 0 10px #00ffe5;
    `;
    
    document.body.appendChild(themeSwitcher);
    
    // Check for saved theme preference or default to dark
    const currentTheme = localStorage.getItem('theme') || 'dark';
    document.body.classList.add(currentTheme);
    
    // Apply theme
    applyTheme(currentTheme);
    
    // Theme switcher click event
    themeSwitcher.addEventListener('click', () => {
      if (document.body.classList.contains('dark')) {
        document.body.classList.replace('dark', 'light');
        localStorage.setItem('theme', 'light');
        applyTheme('light');
      } else {
        document.body.classList.replace('light', 'dark');
        localStorage.setItem('theme', 'dark');
        applyTheme('dark');
      }
    });
  };
  
  // Apply theme to elements
  const applyTheme = (theme) => {
    const root = document.documentElement;
    
    if (theme === 'light') {
      root.style.setProperty('--bg-color', '#f0f8ff');
      root.style.setProperty('--text-color', '#333');
      root.style.setProperty('--header-bg', '#e0f0ff');
      root.style.setProperty('--card-bg', '#fff');
      root.style.setProperty('--card-border', '#00ffe5');
      root.style.setProperty('--accent-color', '#0078d7');
      root.style.setProperty('--shadow-color', 'rgba(0, 120, 215, 0.3)');
    } else {
      root.style.setProperty('--bg-color', 'radial-gradient(circle, #000428, #004e92)');
      root.style.setProperty('--text-color', '#fff');
      root.style.setProperty('--header-bg', '#0f0f3f');
      root.style.setProperty('--card-bg', '#111');
      root.style.setProperty('--card-border', '#00ffe5');
      root.style.setProperty('--accent-color', '#00ffe5');
      root.style.setProperty('--shadow-color', 'rgba(0, 255, 229, 0.5)');
    }
  };
  
  createThemeSwitcher();
});
