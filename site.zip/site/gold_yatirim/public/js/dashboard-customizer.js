document.addEventListener('DOMContentLoaded', () => {
  // Dashboard customization functionality
  class DashboardCustomizer {
    constructor() {
      this.settings = this.loadSettings();
      this.createCustomizerButton();
      this.applySettings();
    }
    
    loadSettings() {
      const defaultSettings = {
        layout: 'default', // default, compact, expanded
        visibleSections: ['balance', 'investments', 'referrals', 'transactions', 'wallet'],
        sectionOrder: ['balance', 'investments', 'referrals', 'transactions', 'wallet'],
        colorScheme: 'default', // default, blue, green, gold
        showStats: true,
        compactView: false,
        animationsEnabled: true
      };
      
      const savedSettings = JSON.parse(localStorage.getItem('dashboardSettings'));
      return savedSettings ? {...defaultSettings, ...savedSettings} : defaultSettings;
    }
    
    saveSettings() {
      localStorage.setItem('dashboardSettings', JSON.stringify(this.settings));
    }
    
    createCustomizerButton() {
      // Sadece dashboard sayfasında göster
      if (!window.location.pathname.includes('/dashboard') && 
          !window.location.pathname.includes('/profile')) {
        return;
      }
      
      const customizerButton = document.createElement('button');
      customizerButton.id = 'dashboard-customizer-btn';
      customizerButton.innerHTML = '⚙️';
      customizerButton.setAttribute('aria-label', 'Panel Ayarları');
      customizerButton.style.cssText = `
        position: fixed;
        bottom: 260px;
        right: 20px;
        background-color: #0f0f3f;
        color: #00ffe5;
        border: none;
        border-radius: 50%;
        width: 50px;
        height: 50px;
        font-size: 24px;
        cursor: pointer;
        z-index: 99;
        box-shadow: 0 0 10px #00ffe5;
      `;
      
      customizerButton.addEventListener('click', () => {
        this.openCustomizerModal();
      });
      
      document.body.appendChild(customizerButton);
    }
    
    openCustomizerModal() {
      // Modal oluştur
      const modal = document.createElement('div');
      modal.className = 'customizer-modal';
      modal.style.cssText = `
        position: fixed;
        top: 0;
        left: 0;
        width: 100%;
        height: 100%;
        background-color: rgba(0, 0, 0, 0.8);
        z-index: 1000;
        display: flex;
        justify-content: center;
        align-items: center;
      `;
      
      // Modal içeriği
      const modalContent = document.createElement('div');
      modalContent.className = 'customizer-modal-content';
      modalContent.style.cssText = `
        background-color: var(--card-bg, #111);
        color: var(--text-color, #fff);
        padding: 25px;
        border-radius: 12px;
        width: 90%;
        max-width: 600px;
        max-height: 80vh;
        overflow-y: auto;
        box-shadow: 0 0 20px var(--accent-color, #00ffe5);
        position: relative;
      `;
      
      // Başlık
      const title = document.createElement('h2');
      title.textContent = 'Panel Kişiselleştirme';
      title.style.cssText = `
        color: var(--accent-color, #00ffe5);
        margin-top: 0;
        border-bottom: 2px solid var(--accent-color, #00ffe5);
        padding-bottom: 10px;
      `;
      
      // Kapat butonu
      const closeButton = document.createElement('button');
      closeButton.innerHTML = '&times;';
      closeButton.style.cssText = `
        position: absolute;
        top: 10px;
        right: 10px;
        background: none;
        border: none;
        color: var(--text-color, #fff);
        font-size: 24px;
        cursor: pointer;
      `;
      
      closeButton.addEventListener('click', () => {
        document.body.removeChild(modal);
      });
      
      // Ayarlar içeriği
      const settingsContent = document.createElement('div');
      
      // 1. Düzen seçimi
      const layoutSection = this.createSection('Düzen');
      const layoutOptions = [
        { value: 'default', label: 'Standart' },
        { value: 'compact', label: 'Kompakt' },
        { value: 'expanded', label: 'Genişletilmiş' }
      ];
      
      const layoutSelector = this.createRadioGroup('layout', layoutOptions, this.settings.layout);
      layoutSection.appendChild(layoutSelector);
      
      // 2. Görünür bölümler
      const sectionsSection = this.createSection('Görünür Bölümler');
      const sectionOptions = [
        { value: 'balance', label: 'Bakiye' },
        { value: 'investments', label: 'Yatırımlar' },
        { value: 'referrals', label: 'Referanslar' },
        { value: 'transactions', label: 'İşlem Geçmişi' },
        { value: 'wallet', label: 'Cüzdan' }
      ];
      
      const sectionCheckboxes = this.createCheckboxGroup('sections', sectionOptions, this.settings.visibleSections);
      sectionsSection.appendChild(sectionCheckboxes);
      
      // 3. Bölüm sıralaması
      const orderSection = this.createSection('Bölüm Sıralaması');
      const orderList = this.createSortableList('sectionOrder', this.settings.sectionOrder, sectionOptions);
      orderSection.appendChild(orderList);
      
      // 4. Renk şeması
      const colorSection = this.createSection('Renk Şeması');
      const colorOptions = [
        { value: 'default', label: 'Varsayılan (Mavi-Yeşil)' },
        { value: 'blue', label: 'Mavi' },
        { value: 'green', label: 'Yeşil' },
        { value: 'gold', label: 'Altın' }
      ];
      
      const colorSelector = this.createRadioGroup('colorScheme', colorOptions, this.settings.colorScheme);
      colorSection.appendChild(colorSelector);
      
      // 5. Diğer ayarlar
      const otherSection = this.createSection('Diğer Ayarlar');
      
      const statsOption = this.createCheckbox('showStats', 'İstatistikleri Göster', this.settings.showStats);
      const compactOption = this.createCheckbox('compactView', 'Kompakt Görünüm', this.settings.compactView);
      const animationsOption = this.createCheckbox('animationsEnabled', 'Animasyonları Etkinleştir', this.settings.animationsEnabled);
      
      otherSection.appendChild(statsOption);
      otherSection.appendChild(compactOption);
      otherSection.appendChild(animationsOption);
      
      // Kaydet butonu
      const saveButton = document.createElement('button');
      saveButton.textContent = 'Ayarları Kaydet';
      saveButton.style.cssText = `
        background-color: var(--accent-color, #00ffe5);
        color: #000;
        border: none;
        border-radius: 8px;
        padding: 12px 24px;
        margin-top: 20px;
        font-weight: bold;
        cursor: pointer;
        width: 100%;
      `;
      
      saveButton.addEventListener('click', () => {
        this.saveCustomizerSettings();
        document.body.removeChild(modal);
        
        // Bildirim göster
        if (window.notificationSystem) {
          window.notificationSystem.showNotification(
            'Panel Ayarları', 
            'Kişiselleştirme ayarlarınız kaydedildi ve uygulandı.', 
            'success'
          );
        }
        
        // Sayfayı yenile
        setTimeout(() => {
          window.location.reload();
        }, 1000);
      });
      
      // Sıfırla butonu
      const resetButton = document.createElement('button');
      resetButton.textContent = 'Varsayılana Sıfırla';
      resetButton.style.cssText = `
        background: none;
        border: 1px solid var(--accent-color, #00ffe5);
        color: var(--accent-color, #00ffe5);
        border-radius: 8px;
        padding: 10px 20px;
        margin-top: 10px;
        cursor: pointer;
        width: 100%;
      `;
      
      resetButton.addEventListener('click', () => {
        localStorage.removeItem('dashboardSettings');
        this.settings = this.loadSettings();
        
        // Bildirim göster
        if (window.notificationSystem) {
          window.notificationSystem.showNotification(
            'Panel Ayarları', 
            'Kişiselleştirme ayarlarınız varsayılana sıfırlandı.', 
            'info'
          );
        }
        
        // Sayfayı yenile
        setTimeout(() => {
          window.location.reload();
        }, 1000);
      });
      
      // Tüm bölümleri ekle
      settingsContent.appendChild(layoutSection);
      settingsContent.appendChild(sectionsSection);
      settingsContent.appendChild(orderSection);
      settingsContent.appendChild(colorSection);
      settingsContent.appendChild(otherSection);
      settingsContent.appendChild(saveButton);
      settingsContent.appendChild(resetButton);
      
      // Modal içeriğini oluştur
      modalContent.appendChild(title);
      modalContent.appendChild(closeButton);
      modalContent.appendChild(settingsContent);
      
      modal.appendChild(modalContent);
      document.body.appendChild(modal);
    }
    
    createSection(title) {
      const section = document.createElement('div');
      section.style.cssText = `
        margin-bottom: 20px;
        padding-bottom: 15px;
        border-bottom: 1px solid rgba(255, 255, 255, 0.1);
      `;
      
      const sectionTitle = document.createElement('h3');
      sectionTitle.textContent = title;
      sectionTitle.style.cssText = `
        margin-bottom: 10px;
        color: var(--accent-color, #00ffe5);
      `;
      
      section.appendChild(sectionTitle);
      return section;
    }
    
    createRadioGroup(name, options, selectedValue) {
      const container = document.createElement('div');
      container.className = 'radio-group';
      container.style.cssText = `
        display: flex;
        flex-wrap: wrap;
        gap: 10px;
      `;
      
      options.forEach(option => {
        const label = document.createElement('label');
        label.style.cssText = `
          display: flex;
          align-items: center;
          margin-right: 15px;
          cursor: pointer;
        `;
        
        const radio = document.createElement('input');
        radio.type = 'radio';
        radio.name = name;
        radio.value = option.value;
        radio.checked = selectedValue === option.value;
        radio.style.cssText = `
          margin-right: 5px;
        `;
        
        const text = document.createTextNode(option.label);
        
        label.appendChild(radio);
        label.appendChild(text);
        container.appendChild(label);
      });
      
      return container;
    }
    
    createCheckboxGroup(name, options, selectedValues) {
      const container = document.createElement('div');
      container.className = 'checkbox-group';
      container.style.cssText = `
        display: flex;
        flex-wrap: wrap;
        gap: 10px;
      `;
      
      options.forEach(option => {
        const label = document.createElement('label');
        label.style.cssText = `
          display: flex;
          align-items: center;
          margin-right: 15px;
          cursor: pointer;
        `;
        
        const checkbox = document.createElement('input');
        checkbox.type = 'checkbox';
        checkbox.name = name;
        checkbox.value = option.value;
        checkbox.checked = selectedValues.includes(option.value);
        checkbox.style.cssText = `
          margin-right: 5px;
        `;
        
        const text = document.createTextNode(option.label);
        
        label.appendChild(checkbox);
        label.appendChild(text);
        container.appendChild(label);
      });
      
      return container;
    }
    
    createCheckbox(name, label, checked) {
      const container = document.createElement('div');
      container.style.cssText = `
        margin-bottom: 10px;
      `;
      
      const labelElement = document.createElement('label');
      labelElement.style.cssText = `
        display: flex;
        align-items: center;
        cursor: pointer;
      `;
      
      const checkbox = document.createElement('input');
      checkbox.type = 'checkbox';
      checkbox.name = name;
      checkbox.checked = checked;
      checkbox.style.cssText = `
        margin-right: 10px;
      `;
      
      const text = document.createTextNode(label);
      
      labelElement.appendChild(checkbox);
      labelElement.appendChild(text);
      container.appendChild(labelElement);
      
      return container;
    }
    
    createSortableList(name, items, options) {
      const container = document.createElement('div');
      container.className = 'sortable-list';
      
      const list = document.createElement('ul');
      list.style.cssText = `
        list-style: none;
        padding: 0;
        margin: 0;
      `;
      
      // Sıralı öğeleri oluştur
      items.forEach((item, index) => {
        const option = options.find(opt => opt.value === item);
        if (!option) return;
        
        const listItem = document.createElement('li');
        listItem.setAttribute('data-value', item);
        listItem.style.cssText = `
          background-color: rgba(0, 255, 229, 0.1);
          padding: 10px 15px;
          margin-bottom: 5px;
          border-radius: 4px;
          cursor: move;
          display: flex;
          justify-content: space-between;
          align-items: center;
        `;
        
        const itemText = document.createElement('span');
        itemText.textContent = option.label;
        
        const controls = document.createElement('div');
        
        const upButton = document.createElement('button');
        upButton.innerHTML = '&uarr;';
        upButton.style.cssText = `
          background: none;
          border: none;
          color: var(--accent-color, #00ffe5);
          cursor: pointer;
          margin-right: 5px;
        `;
        
        const downButton = document.createElement('button');
        downButton.innerHTML = '&darr;';
        downButton.style.cssText = `
          background: none;
          border: none;
          color: var(--accent-color, #00ffe5);
          cursor: pointer;
        `;
        
        upButton.addEventListener('click', (e) => {
          e.preventDefault();
          if (index > 0) {
            // Öğeyi bir üst sıraya taşı
            const temp = items[index];
            items[index] = items[index - 1];
            items[index - 1] = temp;
            
            // Listeyi yeniden oluştur
            container.innerHTML = '';
            container.appendChild(this.createSortableList(name, items, options));
          }
        });
        
        downButton.addEventListener('click', (e) => {
          e.preventDefault();
          if (index < items.length - 1) {
            // Öğeyi bir alt sıraya taşı
            const temp = items[index];
            items[index] = items[index + 1];
            items[index + 1] = temp;
            
            // Listeyi yeniden oluştur
            container.innerHTML = '';
            container.appendChild(this.createSortableList(name, items, options));
          }
        });
        
        controls.appendChild(upButton);
        controls.appendChild(downButton);
        
        listItem.appendChild(itemText);
        listItem.appendChild(controls);
        list.appendChild(listItem);
      });
      
      container.appendChild(list);
      return container;
    }
    
    saveCustomizerSettings() {
      // Düzen seçimi
      const layoutRadios = document.querySelectorAll('input[name="layout"]');
      for (const radio of layoutRadios) {
        if (radio.checked) {
          this.settings.layout = radio.value;
          break;
        }
      }
      
      // Görünür bölümler
      const sectionCheckboxes = document.querySelectorAll('input[name="sections"]');
      this.settings.visibleSections = [];
      for (const checkbox of sectionCheckboxes) {
        if (checkbox.checked) {
          this.settings.visibleSections.push(checkbox.value);
        }
      }
      
      // Bölüm sıralaması
      const sortableItems = document.querySelectorAll('.sortable-list li');
      this.settings.sectionOrder = [];
      for (const item of sortableItems) {
        this.settings.sectionOrder.push(item.getAttribute('data-value'));
      }
      
      // Renk şeması
      const colorRadios = document.querySelectorAll('input[name="colorScheme"]');
      for (const radio of colorRadios) {
        if (radio.checked) {
          this.settings.colorScheme = radio.value;
          break;
        }
      }
      
      // Diğer ayarlar
      this.settings.showStats = document.querySelector('input[name="showStats"]').checked;
      this.settings.compactView = document.querySelector('input[name="compactView"]').checked;
      this.settings.animationsEnabled = document.querySelector('input[name="animationsEnabled"]').checked;
      
      // Ayarları kaydet
      this.saveSettings();
      this.applySettings();
    }
    
    applySettings() {
      // Sadece dashboard veya profile sayfasında uygula
      if (!window.location.pathname.includes('/dashboard') && 
          !window.location.pathname.includes('/profile')) {
        return;
      }
      
      const dashboard = document.querySelector('main');
      if (!dashboard) return;
      
      // 1. Düzen uygula
      dashboard.classList.remove('layout-default', 'layout-compact', 'layout-expanded');
      dashboard.classList.add(`layout-${this.settings.layout}`);
      
      // 2. Görünür bölümler
      const sections = dashboard.querySelectorAll('section');
      sections.forEach(section => {
        const sectionId = section.id || '';
        const sectionClass = Array.from(section.classList).find(cls => 
          cls.includes('section') || cls.includes('-section')
        );
        
        let sectionType = '';
        if (sectionId.includes('balance')) sectionType = 'balance';
        else if (sectionId.includes('investment') || sectionClass?.includes('investment')) sectionType = 'investments';
        else if (sectionId.includes('referral') || sectionClass?.includes('referral')) sectionType = 'referrals';
        else if (sectionId.includes('transaction') || sectionClass?.includes('transaction')) sectionType = 'transactions';
        else if (sectionId.includes('wallet') || sectionClass?.includes('wallet')) sectionType = 'wallet';
        
        if (sectionType && !this.settings.visibleSections.includes(sectionType)) {
          section.style.display = 'none';
        } else {
          section.style.display = '';
        }
      });
      
      // 3. Bölüm sıralaması
      const sectionsContainer = dashboard.querySelector('.sections-container') || dashboard;
      const sectionElements = Array.from(sections);
      
      // Sıralamayı uygula
      this.settings.sectionOrder.forEach((sectionType, index) => {
        const section = sectionElements.find(el => {
          const sectionId = el.id || '';
          const sectionClass = Array.from(el.classList).find(cls => 
            cls.includes('section') || cls.includes('-section')
          );
          
          return (sectionId.includes(sectionType) || sectionClass?.includes(sectionType));
        });
        
        if (section) {
          section.style.order = index;
        }
      });
      
      // 4. Renk şeması
      document.body.classList.remove('color-default', 'color-blue', 'color-green', 'color-gold');
      document.body.classList.add(`color-${this.settings.colorScheme}`);
      
      // Renk şemasına göre CSS değişkenleri
      const root = document.documentElement;
      switch (this.settings.colorScheme) {
        case 'blue':
          root.style.setProperty('--accent-color', '#007bff');
          root.style.setProperty('--secondary-color', '#0056b3');
          break;
        case 'green':
          root.style.setProperty('--accent-color', '#28a745');
          root.style.setProperty('--secondary-color', '#1e7e34');
          break;
        case 'gold':
          root.style.setProperty('--accent-color', '#ffc107');
          root.style.setProperty('--secondary-color', '#d39e00');
          break;
        default:
          root.style.setProperty('--accent-color', '#00ffe5');
          root.style.setProperty('--secondary-color', '#00cfff');
      }
      
      // 5. Diğer ayarlar
      // İstatistikler
      const statsSection = dashboard.querySelector('.stats-section, .dashboard-stats');
      if (statsSection) {
        statsSection.style.display = this.settings.showStats ? '' : 'none';
      }
      
      // Kompakt görünüm
      if (this.settings.compactView) {
        dashboard.classList.add('compact-view');
      } else {
        dashboard.classList.remove('compact-view');
      }
      
      // Animasyonlar
      if (this.settings.animationsEnabled) {
        document.body.classList.remove('no-animations');
      } else {
        document.body.classList.add('no-animations');
        
        // Animasyonları devre dışı bırak
        const style = document.createElement('style');
        style.textContent = `
          * {
            transition: none !important;
            animation: none !important;
          }
        `;
        document.head.appendChild(style);
      }
      
      // CSS ekle
      this.addCustomStyles();
    }
    
    addCustomStyles() {
      const style = document.createElement('style');
      style.textContent = `
        /* Düzen stilleri */
        .layout-compact section {
          padding: 10px !important;
          margin-bottom: 15px !important;
        }
        
        .layout-compact h2 {
          font-size: 1.2rem !important;
          margin-bottom: 10px !important;
        }
        
        .layout-expanded section {
          padding: 25px !important;
          margin-bottom: 30px !important;
        }
        
        .layout-expanded h2 {
          font-size: 1.8rem !important;
          margin-bottom: 20px !important;
        }
        
        /* Kompakt görünüm */
        .compact-view .investment-item,
        .compact-view .transaction-item,
        .compact-view .referred-user-item {
          padding: 8px !important;
          margin-bottom: 8px !important;
        }
        
        .compact-view p {
          margin: 3px 0 !important;
        }
        
        /* Renk şemaları */
        .color-blue button:not([class*="reject"]):not([class*="close"]) {
          background-color: var(--accent-color, #007bff) !important;
        }
        
        .color-green button:not([class*="reject"]):not([class*="close"]) {
          background-color: var(--accent-color, #28a745) !important;
        }
        
        .color-gold button:not([class*="reject"]):not([class*="close"]) {
          background-color: var(--accent-color, #ffc107) !important;
          color: #000 !important;
        }
        
        /* Sıralama için */
        main {
          display: flex;
          flex-direction: column;
        }
        
        section {
          order: 10;
        }
      `;
      
      document.head.appendChild(style);
    }
  }
  
  // Dashboard customizer'ı başlat
  window.dashboardCustomizer = new DashboardCustomizer();
});
