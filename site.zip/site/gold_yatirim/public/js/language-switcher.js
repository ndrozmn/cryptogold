document.addEventListener('DOMContentLoaded', () => {
  // Language switcher functionality
  class LanguageSwitcher {
    constructor() {
      this.currentLanguage = 'tr'; // Sadece Türkçe
      this.translations = {
        tr: {
          'language': 'Dil',
          'home': 'Ana Sayfa',
          'investment': 'Yatırım',
          'login': 'Giriş Yap',
          'register': 'Üye Ol',
          'profile': 'Profil',
          'logout': 'Çıkış Yap',
          'about': 'Hakkımızda',
          'about_title': 'Hakkımızda | Gold Yatırım',
          'about_heading': 'Hakkımızda | Gold Yatırım',
          'wealth_path': '💰 Zenginliğe Uzanan Yol',
          'investment_desc': 'USDT yatırımın en parlak hali burada!',
          'go_to_investment': 'Yatırım Sayfasına Git'
        }
      };
      
      this.applyLanguage();
    }
    
    translate(key) {
      if (this.translations[this.currentLanguage] && this.translations[this.currentLanguage][key]) {
        return this.translations[this.currentLanguage][key];
      } else {
        return key;
      }
    }
    
    applyLanguage() {
      // Tüm data-i18n özniteliği olan elementleri bul ve çevir
      document.querySelectorAll('[data-i18n]').forEach(element => {
        const key = element.getAttribute('data-i18n');
        if (key) {
          element.innerHTML = this.translate(key);
        }
      });
      
      // Placeholder'ları çevir
      document.querySelectorAll('[data-i18n-placeholder]').forEach(element => {
        const key = element.getAttribute('data-i18n-placeholder');
        if (key) {
          element.setAttribute('placeholder', this.translate(key));
        }
      });
    }
  }
  
  // Global erişim için
  window.languageSwitcher = new LanguageSwitcher();
});
