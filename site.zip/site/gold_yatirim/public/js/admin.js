// Admin Panel JavaScript
// This file loads the separate admin modules to avoid size limitations

// Load admin_part1.js - User management
document.write('<script src="/js/admin_part1.js"></script>');

// Load admin_part2.js - Investment management
document.write('<script src="/js/admin_part2.js"></script>');

// Load admin_part3.js - Deposit and withdrawal management
document.write('<script src="/js/admin_part3.js"></script>');

// Load live-support.js - Live support system
document.write('<script src="/js/live-support.js"></script>');

// Load community-chat.js - Community chat system
document.write('<script src="/js/community-chat.js"></script>');

// Initialize admin panel
document.addEventListener('DOMContentLoaded', function() {
  // Canlı destek sistemi için gerekli DOM elementlerini oluştur
  const activeChatsContainer = document.getElementById('activeChatsList');
  if (activeChatsContainer && window.liveSupportSystem) {
    // Aktif sohbetleri güncelle
    window.liveSupportSystem.updateAdminChatsList();
    
    // Her 10 saniyede bir aktif sohbetleri güncelle
    setInterval(() => {
      window.liveSupportSystem.updateAdminChatsList();
    }, 10000);
  }
});
