document.addEventListener('DOMContentLoaded', () => {
  // DOM Elemanları
  const investmentRequests = document.getElementById('investmentRequests');
  const withdrawalRequests = document.getElementById('withdrawalRequests');
  const depositRequests = document.getElementById('depositRequests');
  const investmentEditFormContainer = document.getElementById('investmentEditFormContainer');
  const editInvestmentId = document.getElementById('editInvestmentId');
  const editStockControl = document.getElementById('editStockControl');
  const editPrice = document.getElementById('editPrice');
  const editEarnings = document.getElementById('editEarnings');
  const editPercentage = document.getElementById('editPercentage');
  const cancelEditInvestment = document.getElementById('cancelEditInvestment');
  const investmentEditForm = document.getElementById('investmentEditForm');
  const investmentSettingsTable = document.getElementById('investmentSettingsTable').getElementsByTagName('tbody')[0];

  // Durum metni döndür
  function getStatusText(status) {
    switch (status) {
      case 'pending': return 'Beklemede';
      case 'approved': return 'Onaylandı';
      case 'rejected': return 'Reddedildi';
      default: return status;
    }
  }

  // Yatırım taleplerini yükle ve listele
  async function loadInvestmentRequests() {
    try {
      const res = await fetch('/admin/investment-requests');
      if (!res.ok) {
        throw new Error('Yatırım talepleri yüklenemedi');
      }
      const requests = await res.json();
      displayInvestmentRequests(requests);
    } catch (error) {
      console.error('Yatırım talepleri yüklenirken hata:', error);
    }
  }

  // Yatırım taleplerini göster
  function displayInvestmentRequests(requests) {
    investmentRequests.innerHTML = '';
    
    if (requests.length === 0) {
      investmentRequests.innerHTML = '<p>Bekleyen yatırım talebi bulunmamaktadır.</p>';
      return;
    }
    
    const table = document.createElement('table');
    
    // Tablo başlığı
    const thead = document.createElement('thead');
    const headerRow = document.createElement('tr');
    ['Kullanıcı', 'Miktar', 'Tarih', 'Durum', 'İşlemler'].forEach(text => {
      const th = document.createElement('th');
      th.textContent = text;
      headerRow.appendChild(th);
    });
    thead.appendChild(headerRow);
    table.appendChild(thead);
    
    // Tablo gövdesi
    const tbody = document.createElement('tbody');
    requests.forEach(req => {
      const tr = document.createElement('tr');
      
      // Kullanıcı
      const userTd = document.createElement('td');
      userTd.textContent = req.user && req.user.username ? req.user.username : req.user;
      tr.appendChild(userTd);
      
      // Miktar
      const amountTd = document.createElement('td');
      amountTd.textContent = `${req.amount || req.usdtAmount || '0'} USDT`;
      tr.appendChild(amountTd);
      
      // Tarih
      const dateTd = document.createElement('td');
      dateTd.textContent = new Date(req.startDate || req.requestedAt || Date.now()).toLocaleDateString();
      tr.appendChild(dateTd);
      
      // Durum
      const statusTd = document.createElement('td');
      const statusSpan = document.createElement('span');
      statusSpan.className = `status ${req.status || 'pending'}`;
      statusSpan.textContent = getStatusText(req.status || 'pending');
      statusTd.appendChild(statusSpan);
      tr.appendChild(statusTd);
      
      // İşlemler
      const actionsTd = document.createElement('td');
      
      // Onayla butonu
      const approveBtn = document.createElement('button');
      approveBtn.textContent = 'Onayla';
      approveBtn.addEventListener('click', () => {
        if (confirm('Bu yatırım talebini onaylamak istiyor musunuz?')) {
          approveInvestment(req._id);
        }
      });
      actionsTd.appendChild(approveBtn);
      
      // Reddet butonu
      const rejectBtn = document.createElement('button');
      rejectBtn.textContent = 'Reddet';
      rejectBtn.addEventListener('click', () => {
        if (confirm('Bu yatırım talebini reddetmek istiyor musunuz?')) {
          rejectInvestment(req._id);
        }
      });
      actionsTd.appendChild(rejectBtn);
      
      // Düzenle butonu
      const editBtn = document.createElement('button');
      editBtn.textContent = 'Düzenle';
      editBtn.addEventListener('click', () => {
        openEditInvestmentForm(req);
      });
      actionsTd.appendChild(editBtn);
      
      tr.appendChild(actionsTd);
      tbody.appendChild(tr);
    });
    
    table.appendChild(tbody);
    investmentRequests.appendChild(table);
  }

  // Yatırım talebini onayla
  async function approveInvestment(investmentId) {
    try {
      const res = await fetch(`/admin/investment-requests/${investmentId}/approve`, {
        method: 'POST'
      });
      if (res.ok) {
        alert('Yatırım talebi onaylandı');
        loadInvestmentRequests();
      } else {
        alert('Yatırım talebi onaylanırken hata oluştu');
      }
    } catch (error) {
      console.error('Yatırım onaylama hatası:', error);
    }
  }

  // Yatırım talebini reddet
  async function rejectInvestment(investmentId) {
    try {
      const res = await fetch(`/admin/investment-requests/${investmentId}/reject`, {
        method: 'POST'
      });
      if (res.ok) {
        alert('Yatırım talebi reddedildi');
        loadInvestmentRequests();
      } else {
        alert('Yatırım talebi reddedilirken hata oluştu');
      }
    } catch (error) {
      console.error('Yatırım reddetme hatası:', error);
    }
  }

  // Düzenleme formunu aç
  function openEditInvestmentForm(investment) {
    investmentEditFormContainer.style.display = 'flex';
    editInvestmentId.value = investment._id;
    editStockControl.value = investment.stockControl || 0;
    editPrice.value = investment.price || 0;
    editEarnings.value = investment.earnings || 0;
    editPercentage.value = investment.percentage || 0;
  }

  // Düzenleme formunu kapat
  cancelEditInvestment.addEventListener('click', () => {
    investmentEditFormContainer.style.display = 'none';
  });

  // Düzenleme formu gönderimi
  investmentEditForm.addEventListener('submit', async (e) => {
    e.preventDefault();
    const investmentId = editInvestmentId.value;
    const data = {
      stockControl: parseInt(editStockControl.value, 10),
      price: parseFloat(editPrice.value),
      earnings: parseFloat(editEarnings.value),
      percentage: parseFloat(editPercentage.value),
    };
    try {
      const res = await fetch(`/admin/investment-requests/${investmentId}/update`, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(data),
      });
      if (res.ok) {
        alert('Yatırım ayarları güncellendi');
        investmentEditFormContainer.style.display = 'none';
        loadInvestmentRequests();
      } else {
        alert('Yatırım ayarları güncellenirken hata oluştu');
      }
    } catch (error) {
      console.error('Yatırım ayarları güncelleme hatası:', error);
    }
  });

  // Yatırım ayarlarını yükle
  async function loadInvestmentSettings() {
    try {
      const res = await fetch('/admin/investment-settings');
      if (!res.ok) {
        throw new Error('Yatırım ayarları yüklenemedi');
      }
      const settings = await res.json();
      displayInvestmentSettings(settings);
    } catch (error) {
      console.error('Yatırım ayarları yüklenirken hata:', error);
    }
  }

  // Yatırım ayarlarını göster
  function displayInvestmentSettings(settings) {
    investmentSettingsTable.innerHTML = '';
    
    if (settings.length === 0) {
      const tr = document.createElement('tr');
      const td = document.createElement('td');
      td.colSpan = 6;
      td.textContent = 'Yatırım ayarı bulunmamaktadır.';
      td.style.textAlign = 'center';
      tr.appendChild(td);
      investmentSettingsTable.appendChild(tr);
      return;
    }
    
    settings.forEach(setting => {
      const tr = document.createElement('tr');
      
      // Yatırım adı
      const nameTd = document.createElement('td');
      nameTd.textContent = setting.name || 'İsimsiz Yatırım';
      tr.appendChild(nameTd);
      
      // Fiyat
      const priceTd = document.createElement('td');
      priceTd.textContent = `${setting.price || '0'} USDT`;
      tr.appendChild(priceTd);
      
      // Kilitleme
      const lockDaysTd = document.createElement('td');
      lockDaysTd.textContent = `${setting.lockDays || '0'} gün`;
      tr.appendChild(lockDaysTd);
      
      // Komisyon
      const interestRateTd = document.createElement('td');
      interestRateTd.textContent = `${setting.interestRate || setting.percentage || '0'}%`;
      tr.appendChild(interestRateTd);
      
      // Stok kontrolü
      const stockControlTd = document.createElement('td');
      stockControlTd.textContent = setting.stockControl || '0';
      tr.appendChild(stockControlTd);
      
      // İşlemler
      const actionsTd = document.createElement('td');
      
      // Düzenle butonu
      const editBtn = document.createElement('button');
      editBtn.textContent = 'Düzenle';
      editBtn.addEventListener('click', () => {
        openEditInvestmentForm(setting);
      });
      actionsTd.appendChild(editBtn);
      
      tr.appendChild(actionsTd);
      investmentSettingsTable.appendChild(tr);
    });
  }

  // Fonksiyonları global olarak tanımla
  window.loadInvestmentRequests = loadInvestmentRequests;
  window.loadInvestmentSettings = loadInvestmentSettings;
});
