// Canlı Destek Sistemi
// Global değişken olarak liveSupportSystem'i tanımla
window.liveSupportSystem = {
  activeSupportChats: {},
  updateAdminPanel: updateAdminPanel,
  updateAdminChatMessages: updateAdminChatMessages,
  showAdminChatDetail: showAdminChatDetail,
  renderAdminChatMessages: renderAdminChatMessages,
  updateAdminChatsList: updateAdminChatsList,
  playNotificationSound: playNotificationSound
};

document.addEventListener('DOMContentLoaded', function() {
  // Canlı destek butonu oluştur
  createSupportButton();
  
  // Admin paneli varsa kurulumu yap
  if (document.querySelector('.admin-section')) {
    setupAdminPanel();
  }
});

// Canlı destek butonu oluşturma
function createSupportButton() {
  const supportButton = document.createElement('div');
  supportButton.id = 'live-support-button';
  supportButton.innerHTML = '<i class="fas fa-comments"></i> Canlı Destek';
  supportButton.style.position = 'fixed';
  supportButton.style.bottom = '20px';
  supportButton.style.right = '20px';
  supportButton.style.backgroundColor = '#0f0f3f';
  supportButton.style.color = '#00ffe5';
  supportButton.style.padding = '10px 20px';
  supportButton.style.borderRadius = '30px';
  supportButton.style.cursor = 'pointer';
  supportButton.style.boxShadow = '0 2px 10px rgba(0, 0, 0, 0.2)';
  supportButton.style.zIndex = '9998';
  supportButton.style.fontWeight = 'bold';
  
  supportButton.addEventListener('click', function() {
    toggleSupportChat();
  });
  
  document.body.appendChild(supportButton);
}

// Destek sohbet penceresini aç/kapat
function toggleSupportChat() {
  let chatWindow = document.getElementById('live-support-chat');
  
  if (chatWindow) {
    chatWindow.remove();
  } else {
    showUserInfoForm();
  }
}

// Kullanıcı bilgi formunu göster
function showUserInfoForm() {
  // Kullanıcı bilgilerini otomatik olarak oluştur
  const name = "Ziyaretçi_" + Math.floor(Math.random() * 1000);
  const email = "";
  const issue = "Genel Soru";
  
  // Doğrudan sohbeti başlat
  startChat(name, email, issue);
}

// Sohbeti başlat
function startChat(name, email, issue) {
  // Önceki pencereyi kaldır
  const oldWindow = document.getElementById('live-support-chat');
  if (oldWindow) {
    oldWindow.remove();
  }
  
  // Sohbet penceresini oluştur
  const chatWindow = document.createElement('div');
  chatWindow.id = 'live-support-chat';
  chatWindow.style.position = 'fixed';
  chatWindow.style.bottom = '80px';
  chatWindow.style.right = '20px';
  chatWindow.style.width = '350px';
  chatWindow.style.height = '500px';
  chatWindow.style.backgroundColor = '#fff';
  chatWindow.style.borderRadius = '10px';
  chatWindow.style.boxShadow = '0 5px 25px rgba(0, 0, 0, 0.2)';
  chatWindow.style.zIndex = '9999';
  chatWindow.style.display = 'flex';
  chatWindow.style.flexDirection = 'column';
  chatWindow.style.overflow = 'hidden';
  
  // Başlık
  const header = document.createElement('div');
  header.style.backgroundColor = '#0f0f3f';
  header.style.color = '#00ffe5';
  header.style.padding = '15px';
  header.style.fontWeight = 'bold';
  header.style.display = 'flex';
  header.style.justifyContent = 'space-between';
  header.style.alignItems = 'center';
  
  const headerTitle = document.createElement('div');
  headerTitle.textContent = 'Gold Yatırım Canlı Destek';
  
  const headerActions = document.createElement('div');
  headerActions.style.display = 'flex';
  headerActions.style.gap = '15px';
  
  const hideButton = document.createElement('div');
  hideButton.textContent = 'Sakla';
  hideButton.style.cursor = 'pointer';
  hideButton.style.marginRight = '10px';
  
  hideButton.addEventListener('click', function() {
    chatWindow.style.display = 'none';
    
    // Saklanan sohbeti göstermek için butonu güncelle
    const supportButton = document.getElementById('live-support-button');
    if (supportButton) {
      supportButton.innerHTML = '<i class="fas fa-comments"></i> Sohbeti Göster';
    }
  });
  
  const closeButton = document.createElement('div');
  closeButton.textContent = '✖';
  closeButton.style.cursor = 'pointer';
  
  closeButton.addEventListener('click', function() {
    if (confirm('Sohbeti sonlandırmak istediğinize emin misiniz?')) {
      chatWindow.remove();
      
      // Sohbet sonlandırıldı bilgisini admin paneline gönder
      if (window.parent && window.parent.document.getElementById('adminPanel')) {
        // Admin paneline bildirim gönder
      }
    }
  });
  
  headerActions.appendChild(hideButton);
  headerActions.appendChild(closeButton);
  
  header.appendChild(headerTitle);
  header.appendChild(headerActions);
  
  // Mesaj alanı
  const messagesContainer = document.createElement('div');
  messagesContainer.id = 'support-chat-messages';
  messagesContainer.style.flex = '1';
  messagesContainer.style.overflowY = 'auto';
  messagesContainer.style.padding = '15px';
  
  // Sistem mesajı ekle
  const welcomeMessage = document.createElement('div');
  welcomeMessage.className = 'support-chat-message system';
  welcomeMessage.style.backgroundColor = '#f9f9f9';
  welcomeMessage.style.color = '#666';
  welcomeMessage.style.textAlign = 'center';
  welcomeMessage.style.padding = '10px';
  welcomeMessage.style.borderRadius = '5px';
  welcomeMessage.style.marginBottom = '15px';
  welcomeMessage.style.fontSize = '0.9em';
  welcomeMessage.style.fontStyle = 'italic';
  welcomeMessage.innerHTML = `Hoş geldiniz, ${name}! Destek ekibimize bağlanıyorsunuz...<br><small>${new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' })}</small>`;
  
  messagesContainer.appendChild(welcomeMessage);
  
  // Temsilci mesajı ekle
  setTimeout(function() {
    const agentMessage = document.createElement('div');
    agentMessage.className = 'support-chat-message agent';
    agentMessage.style.backgroundColor = '#000428';
    agentMessage.style.marginRight = 'auto';
    agentMessage.style.padding = '10px';
    agentMessage.style.borderRadius = '5px';
    agentMessage.style.maxWidth = '80%';
    agentMessage.style.marginBottom = '15px';
    agentMessage.style.borderBottomLeftRadius = '0';
    agentMessage.style.color = '#fff';
    agentMessage.style.border = '1px solid #ffe600';
    agentMessage.style.boxShadow = '0 0 10px rgba(255, 230, 0, 0.3)';
    
    const messageContent = document.createElement('div');
    messageContent.textContent = `Merhaba ${name}, ben Destek Temsilcisi. Size nasıl yardımcı olabilirim?`;
    
    const messageInfo = document.createElement('div');
    messageInfo.style.fontSize = '0.8em';
    messageInfo.style.marginTop = '5px';
    messageInfo.style.color = '#999';
    messageInfo.textContent = `Destek Temsilcisi • ${new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' })}`;
    
    agentMessage.appendChild(messageContent);
    agentMessage.appendChild(messageInfo);
    
    messagesContainer.appendChild(agentMessage);
    messagesContainer.scrollTop = messagesContainer.scrollHeight;
    
    // Sorun kategorisine göre önerilen yanıtlar
    if (issue !== 'Genel Soru' && issue !== 'Diğer') {
      setTimeout(function() {
        const suggestionMessage = document.createElement('div');
        suggestionMessage.className = 'support-chat-message agent';
        suggestionMessage.style.backgroundColor = '#f0f0f0';
        suggestionMessage.style.marginRight = 'auto';
        suggestionMessage.style.padding = '10px';
        suggestionMessage.style.borderRadius = '5px';
        suggestionMessage.style.maxWidth = '80%';
        suggestionMessage.style.marginBottom = '15px';
        suggestionMessage.style.borderBottomLeftRadius = '0';
        
        const messageContent = document.createElement('div');
        
        if (issue === 'Yatırım Yapmak İstiyorum') {
          messageContent.innerHTML = 'Yatırım yapmak için öncelikle hesabınıza USDT yüklemeniz gerekmektedir. Yatırım paketlerimiz %3, %5, %7 ve %10 kazanç sağlamaktadır. Size hangi konuda yardımcı olabilirim?';
        } else if (issue === 'Para Yatırma Sorunu') {
          messageContent.innerHTML = 'Para yatırma işlemi için TRON (TRC20) ağını kullanmanız gerekmektedir. İşleminizle ilgili detayları paylaşabilir misiniz?';
        } else if (issue === 'Para Çekme Sorunu') {
          messageContent.innerHTML = 'Para çekme işlemleri 24 saat içinde tamamlanmaktadır. Yaşadığınız sorunu detaylı olarak anlatabilir misiniz?';
        } else if (issue === 'Hesap Bilgilerimi Güncellemek İstiyorum') {
          messageContent.innerHTML = 'Hesap bilgilerinizi güncellemek için profil sayfanıza gitmeniz gerekmektedir. Hangi bilgiyi güncellemek istiyorsunuz?';
        } else if (issue === 'Teknik Sorun Yaşıyorum') {
          messageContent.innerHTML = 'Teknik sorunları çözmek için öncelikle tarayıcınızın önbelleğini temizlemenizi öneririz. Yaşadığınız sorunu detaylı olarak anlatabilir misiniz?';
        }
        
        const messageInfo = document.createElement('div');
        messageInfo.style.fontSize = '0.8em';
        messageInfo.style.marginTop = '5px';
        messageInfo.style.color = '#999';
        messageInfo.textContent = `Destek Temsilcisi • ${new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' })}`;
        
        suggestionMessage.appendChild(messageContent);
        suggestionMessage.appendChild(messageInfo);
        
        messagesContainer.appendChild(suggestionMessage);
        messagesContainer.scrollTop = messagesContainer.scrollHeight;
      }, 2000);
    }
    
    // Admin paneline bildirim gönder
    if (window.parent && window.parent.document.getElementById('adminPanel')) {
      // Yeni sohbet bildirimi
      const notificationSound = new Audio('https://assets.mixkit.co/sfx/preview/mixkit-software-interface-start-2574.mp3');
      notificationSound.play().catch(e => console.log('Ses çalınamadı:', e));
      
      // Admin panelini güncelle
      updateAdminPanel(name, email, issue);
    }
  }, 1000);
  
  // Mesaj giriş alanı
  const inputContainer = document.createElement('div');
  inputContainer.style.borderTop = '1px solid #eee';
  inputContainer.style.padding = '15px';
  inputContainer.style.display = 'flex';
  
  const messageInput = document.createElement('input');
  messageInput.type = 'text';
  messageInput.id = 'support-chat-input';
  messageInput.placeholder = 'Mesajınızı yazın...';
  messageInput.style.flex = '1';
  messageInput.style.padding = '10px';
  messageInput.style.border = '1px solid #ddd';
  messageInput.style.borderRadius = '4px';
  messageInput.style.marginRight = '10px';
  
  const sendButton = document.createElement('button');
  sendButton.textContent = 'Gönder';
  sendButton.style.backgroundColor = '#0f0f3f';
  sendButton.style.color = '#00ffe5';
  sendButton.style.border = 'none';
  sendButton.style.borderRadius = '4px';
  sendButton.style.padding = '10px 15px';
  sendButton.style.cursor = 'pointer';
  
// Mesaj gönderme işlevi
const sendMessage = function() {
  const content = messageInput.value.trim();
  if (content) {
    // Kullanıcı mesajı ekle
    const userMessage = document.createElement('div');
    userMessage.className = 'support-chat-message user';
    userMessage.style.backgroundColor = '#333';
    userMessage.style.marginLeft = 'auto';
    userMessage.style.padding = '10px';
    userMessage.style.borderRadius = '5px';
    userMessage.style.maxWidth = '80%';
    userMessage.style.marginBottom = '15px';
    userMessage.style.borderBottomRightRadius = '0';
    userMessage.style.color = '#fff';
    userMessage.style.border = '1px solid #00ffe5';
    userMessage.style.boxShadow = '0 0 10px rgba(0, 255, 229, 0.3)';
    
    const messageContent = document.createElement('div');
    messageContent.textContent = content;
    
    const messageInfo = document.createElement('div');
    messageInfo.style.fontSize = '0.8em';
    messageInfo.style.marginTop = '5px';
    messageInfo.style.color = '#aaa';
    messageInfo.textContent = `${name} • ${new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' })}`;
    
    userMessage.appendChild(messageContent);
    userMessage.appendChild(messageInfo);
    
    messagesContainer.appendChild(userMessage);
    messagesContainer.scrollTop = messagesContainer.scrollHeight;
    
    messageInput.value = '';
    
    // Mesaj gönderildiğini göster
    const messageStatus = document.createElement('div');
    messageStatus.className = 'message-status';
    messageStatus.style.textAlign = 'center';
    messageStatus.style.fontSize = '0.8em';
    messageStatus.style.color = '#aaa';
    messageStatus.style.margin = '5px 0 15px';
    messageStatus.textContent = 'Mesajınız gönderildi';
    messagesContainer.appendChild(messageStatus);
    
    // Admin paneline bildirim gönder
    playNotificationSound();
    
    // Kullanıcı ID'si oluştur veya mevcut ID'yi kullan
    const userId = localStorage.getItem('supportChatUserId') || `user_${Date.now().toString(36)}`;
    localStorage.setItem('supportChatUserId', userId);
    
    // Sohbet ID'si oluştur veya mevcut ID'yi kullan
    const chatId = localStorage.getItem('supportChatId');
    
    // Admin panelini güncelle
    if (chatId) {
      // Mevcut sohbete mesaj ekle
      window.liveSupportSystem.updateAdminChatMessages(name, content, chatId);
    } else {
      // Yeni sohbet oluştur
      const newChatId = updateAdminPanel(name, email, issue);
      localStorage.setItem('supportChatId', newChatId);
      
      // Yeni sohbete mesaj ekle
      window.liveSupportSystem.updateAdminChatMessages(name, content, newChatId);
    }
    
    // 3 saniye sonra mesaj durumunu kaldır
    setTimeout(() => {
      messageStatus.remove();
    }, 3000);
  }
};
  
  sendButton.addEventListener('click', sendMessage);
  
  messageInput.addEventListener('keypress', function(e) {
    if (e.key === 'Enter') {
      sendMessage();
    }
  });
  
  inputContainer.appendChild(messageInput);
  inputContainer.appendChild(sendButton);
  
  // Bileşenleri bir araya getir
  chatWindow.appendChild(header);
  chatWindow.appendChild(messagesContainer);
  chatWindow.appendChild(inputContainer);
  
  document.body.appendChild(chatWindow);
  
  // Input'a odaklan
  messageInput.focus();
}

// Aktif sohbetleri saklamak için global değişken
const activeSupportChats = {};

// Admin panelini güncelle
function updateAdminPanel(name, email, issue) {
  // Yeni bir sohbet ID'si oluştur
  const chatId = `chat_${Date.now()}`;
  
  // Sohbet bilgilerini sakla
  activeSupportChats[chatId] = {
    id: chatId,
    name: name,
    email: email,
    issue: issue,
    status: 'active',
    startTime: new Date(),
    messages: [{
      sender: 'system',
      content: `Hoş geldiniz, ${name}! Destek ekibimize bağlanıyorsunuz...`,
      time: new Date()
    }, {
      sender: 'agent',
      content: `Merhaba ${name}, ben Destek Temsilcisi. Size nasıl yardımcı olabilirim?`,
      time: new Date()
    }]
  };
  
  // Sorun kategorisine göre otomatik mesaj ekle
  if (issue !== 'Genel Soru' && issue !== 'Diğer') {
    let autoMessage = '';
    
    if (issue === 'Yatırım Yapmak İstiyorum') {
      autoMessage = 'Yatırım yapmak için öncelikle hesabınıza USDT yüklemeniz gerekmektedir. Yatırım paketlerimiz %3, %5, %7 ve %10 kazanç sağlamaktadır. Size hangi konuda yardımcı olabilirim?';
    } else if (issue === 'Para Yatırma Sorunu') {
      autoMessage = 'Para yatırma işlemi için TRON (TRC20) ağını kullanmanız gerekmektedir. İşleminizle ilgili detayları paylaşabilir misiniz?';
    } else if (issue === 'Para Çekme Sorunu') {
      autoMessage = 'Para çekme işlemleri 24 saat içinde tamamlanmaktadır. Yaşadığınız sorunu detaylı olarak anlatabilir misiniz?';
    } else if (issue === 'Hesap Bilgilerimi Güncellemek İstiyorum') {
      autoMessage = 'Hesap bilgilerinizi güncellemek için profil sayfanıza gitmeniz gerekmektedir. Hangi bilgiyi güncellemek istiyorsunuz?';
    } else if (issue === 'Teknik Sorun Yaşıyorum') {
      autoMessage = 'Teknik sorunları çözmek için öncelikle tarayıcınızın önbelleğini temizlemenizi öneririz. Yaşadığınız sorunu detaylı olarak anlatabilir misiniz?';
    }
    
    if (autoMessage) {
      activeSupportChats[chatId].messages.push({
        sender: 'agent',
        content: autoMessage,
        time: new Date()
      });
    }
  }
  
  // Admin panelini güncelle
  updateAdminChatsList();
  
  // Bildirim sesi çal
  playNotificationSound();
  
  return chatId;
}

// Admin panelindeki sohbet mesajlarını güncelle
function updateAdminChatMessages(name, content, chatId) {
  // Eğer chatId belirtilmemişse, isim ile eşleşen sohbeti bul
  if (!chatId) {
    for (const id in activeSupportChats) {
      if (activeSupportChats[id].name === name) {
        chatId = id;
        break;
      }
    }
  }
  
  // Sohbet bulunamadıysa yeni oluştur
  if (!chatId || !activeSupportChats[chatId]) {
    chatId = `chat_${Date.now()}`;
    activeSupportChats[chatId] = {
      id: chatId,
      name: name,
      email: '',
      issue: 'Genel Soru',
      status: 'active',
      startTime: new Date(),
      messages: []
    };
  }
  
  // Mesajı ekle
  activeSupportChats[chatId].messages.push({
    sender: 'user',
    content: content,
    time: new Date()
  });
  
  // Admin panelini güncelle
  updateAdminChatsList();
  
  // Eğer sohbet detayı açıksa, mesajları güncelle
  const openChatId = document.querySelector('.chat-detail')?.getAttribute('data-chat-id');
  if (openChatId === chatId) {
    renderAdminChatMessages(chatId);
  }
  
  // Bildirim sesi çal
  playNotificationSound();
}

// Bildirim sesi çal
function playNotificationSound() {
  const notificationSound = new Audio('https://assets.mixkit.co/sfx/preview/mixkit-message-pop-alert-2354.mp3');
  notificationSound.volume = 0.7;
  notificationSound.play().catch(e => console.log('Ses çalınamadı:', e));
  
  // Bildirim göster
  showNotification();
}

// Bildirim göster
function showNotification() {
  // Eğer admin paneli açıksa, bildirim göster
  const adminPanel = document.getElementById('adminPanel');
  if (adminPanel) {
    // Canlı destek butonunu bul
    const liveSupportBtn = document.getElementById('btnLiveSupport');
    if (liveSupportBtn && !liveSupportBtn.classList.contains('has-notification')) {
      // Bildirim işareti ekle
      const notificationBadge = document.createElement('span');
      notificationBadge.className = 'notification-badge';
      notificationBadge.textContent = '!';
      liveSupportBtn.appendChild(notificationBadge);
      liveSupportBtn.classList.add('has-notification');
      
      // Buton animasyonu
      liveSupportBtn.classList.add('pulse-animation');
      setTimeout(() => {
        liveSupportBtn.classList.remove('pulse-animation');
      }, 2000);
    }
  }
}

// Admin panelindeki sohbet listesini güncelle
function updateAdminChatsList() {
  // Aktif sohbetler listesi
  const activeChatsList = document.getElementById('activeChatsList');
  if (activeChatsList) {
    // Listeyi temizle
    activeChatsList.innerHTML = '';
    
    // Aktif sohbet sayısını güncelle
    const activeChatsCount = document.getElementById('activeChatsCount');
    if (activeChatsCount) {
      const count = Object.values(activeSupportChats).filter(chat => chat.status === 'active').length;
      activeChatsCount.textContent = count;
    }
    
    // Eğer aktif sohbet yoksa
    if (Object.keys(activeSupportChats).length === 0) {
      const noData = document.createElement('div');
      noData.className = 'no-data';
      noData.textContent = 'Aktif sohbet bulunmamaktadır.';
      activeChatsList.appendChild(noData);
      return;
    }
    
    // Aktif sohbetleri listele
    Object.values(activeSupportChats)
      .filter(chat => chat.status === 'active')
      .sort((a, b) => new Date(b.startTime) - new Date(a.startTime))
      .forEach(chat => {
        const chatItem = document.createElement('div');
        chatItem.className = 'chat-item';
        chatItem.setAttribute('data-chat-id', chat.id);
        
        // Son mesajı bul
        const lastMessage = chat.messages[chat.messages.length - 1];
        const lastMessageTime = lastMessage ? new Date(lastMessage.time).toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' }) : '';
        
        // Okunmamış mesaj sayısını hesapla
        const unreadCount = chat.messages.filter(msg => msg.sender === 'user' && !msg.read).length;
        
        chatItem.innerHTML = `
          <div class="chat-info">
            <div class="chat-name">${chat.name}</div>
            <div class="chat-issue">${chat.issue}</div>
            <div class="chat-last-message">${lastMessage ? (lastMessage.content.length > 30 ? lastMessage.content.substring(0, 30) + '...' : lastMessage.content) : ''}</div>
          </div>
          <div class="chat-meta">
            <div class="chat-time">${lastMessageTime}</div>
            ${unreadCount > 0 ? `<div class="unread-badge">${unreadCount}</div>` : ''}
          </div>
        `;
        
        chatItem.addEventListener('click', function() {
          showAdminChatDetail(chat.id);
        });
        
        activeChatsList.appendChild(chatItem);
      });
  }
}

// Admin panelinde sohbet detayını göster
function showAdminChatDetail(chatId) {
  const chat = activeSupportChats[chatId];
  if (!chat) return;
  
  // Tüm sohbet öğelerinin seçili sınıfını kaldır
  document.querySelectorAll('.chat-item').forEach(item => {
    item.classList.remove('selected');
  });
  
  // Seçilen sohbet öğesini işaretle
  const selectedChatItem = document.querySelector(`.chat-item[data-chat-id="${chatId}"]`);
  if (selectedChatItem) {
    selectedChatItem.classList.add('selected');
  }
  
  // Mevcut detay görünümünü kaldır
  const existingDetail = document.querySelector('.chat-detail');
  if (existingDetail) {
    existingDetail.remove();
  }
  
  // Detay görünümü oluştur
  const chatDetail = document.createElement('div');
  chatDetail.className = 'chat-detail';
  chatDetail.setAttribute('data-chat-id', chatId);
  
  // Başlık
  const header = document.createElement('div');
  header.className = 'chat-detail-header';
  header.innerHTML = `
    <div class="chat-user-info">
      <div class="chat-user-name">${chat.name}</div>
      <div class="chat-user-email">${chat.email}</div>
    </div>
    <div class="chat-actions">
      <button class="end-chat-btn">Sohbeti Sonlandır</button>
    </div>
  `;
  
  // Mesaj alanı
  const messagesContainer = document.createElement('div');
  messagesContainer.className = 'chat-messages';
  
  // Mesaj giriş alanı
  const inputContainer = document.createElement('div');
  inputContainer.className = 'chat-input-container';
  inputContainer.innerHTML = `
    <input type="text" class="chat-input" placeholder="Mesajınızı yazın...">
    <button class="send-btn">Gönder</button>
  `;
  
  // Mesaj gönderme işlevi
  const sendMessage = () => {
    const input = inputContainer.querySelector('.chat-input');
    const content = input.value.trim();
    
    if (content) {
      // Mesajı ekle
      chat.messages.push({
        sender: 'agent',
        content: content,
        time: new Date()
      });
      
      // Mesajları güncelle
      renderAdminChatMessages(chatId);
      
      // Input'u temizle
      input.value = '';
      
      // Kullanıcı tarafındaki sohbeti güncelle (gerçek uygulamada WebSocket veya başka bir yöntemle yapılır)
      // Bu örnek için sadece konsola yazdırıyoruz
      console.log(`Temsilci mesajı gönderildi: ${content}`);
    }
  };
  
  // Gönder butonuna tıklama
  inputContainer.querySelector('.send-btn').addEventListener('click', sendMessage);
  
  // Enter tuşuna basma
  inputContainer.querySelector('.chat-input').addEventListener('keypress', function(e) {
    if (e.key === 'Enter') {
      sendMessage();
    }
  });
  
  // Sohbeti sonlandır butonuna tıklama
  header.querySelector('.end-chat-btn').addEventListener('click', function() {
    if (confirm('Bu sohbeti sonlandırmak istediğinize emin misiniz?')) {
      chat.status = 'ended';
      chat.endTime = new Date();
      
      // Sistem mesajı ekle
      chat.messages.push({
        sender: 'system',
        content: 'Sohbet sonlandırıldı.',
        time: new Date()
      });
      
      // Mesajları güncelle
      renderAdminChatMessages(chatId);
      
      // Sohbet listesini güncelle
      updateAdminChatsList();
      
      // Detay görünümünü kaldır
      setTimeout(() => {
        chatDetail.remove();
      }, 2000);
    }
  });
  
  // Bileşenleri bir araya getir
  chatDetail.appendChild(header);
  chatDetail.appendChild(messagesContainer);
  chatDetail.appendChild(inputContainer);
  
  // Detay görünümünü ekle
  const supportDashboard = document.getElementById('supportDashboard');
  if (supportDashboard) {
    supportDashboard.appendChild(chatDetail);
  }
  
  // Mesajları göster
  renderAdminChatMessages(chatId);
  
  // Mesajları okundu olarak işaretle
  chat.messages.forEach(msg => {
    if (msg.sender === 'user') {
      msg.read = true;
    }
  });
  
  // Sohbet listesini güncelle (okunmamış mesaj sayısını güncellemek için)
  updateAdminChatsList();
}

// Admin panelinde sohbet mesajlarını göster
function renderAdminChatMessages(chatId) {
  const chat = activeSupportChats[chatId];
  if (!chat) return;
  
  const messagesContainer = document.querySelector(`.chat-detail[data-chat-id="${chatId}"] .chat-messages`);
  if (!messagesContainer) return;
  
  // Mesajları temizle
  messagesContainer.innerHTML = '';
  
  // Mesajları göster
  chat.messages.forEach(msg => {
    const messageEl = document.createElement('div');
    messageEl.className = `chat-message ${msg.sender}`;
    
    const time = new Date(msg.time).toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' });
    
    if (msg.sender === 'system') {
      messageEl.innerHTML = `
        <div class="message-content system-message">${msg.content}</div>
        <div class="message-time">${time}</div>
      `;
    } else if (msg.sender === 'user') {
      // Kullanıcı mesajları
      const isRead = msg.read ? '' : 'style="font-weight: bold; color: #ffe600; text-shadow: 0 0 5px #ffe600;"';
      messageEl.innerHTML = `
        <div class="message-content" ${isRead}>${msg.content}</div>
        <div class="message-info">
          <span class="message-sender">${chat.name}</span>
          <span class="message-time">${time}</span>
          ${!msg.read ? '<span class="message-status" style="color: #ffe600; margin-left: 5px;">(Yeni)</span>' : ''}
        </div>
      `;
    } else {
      // Temsilci mesajları
      messageEl.innerHTML = `
        <div class="message-content">${msg.content}</div>
        <div class="message-info">
          <span class="message-sender">Destek Temsilcisi</span>
          <span class="message-time">${time}</span>
        </div>
      `;
    }
    
    messagesContainer.appendChild(messageEl);
  });
  
  // Otomatik kaydırma
  messagesContainer.scrollTop = messagesContainer.scrollHeight;
}

// Admin paneli kurulumu
function setupAdminPanel() {
  // Admin panelini global olarak tanımla
  window.adminPanel = document.querySelector('.admin-section');
  
  // Aktif sohbetleri global değişkene aktar
  window.liveSupportSystem.activeSupportChats = activeSupportChats;
  
  // Canlı Destek sekmesi ekle
  const adminNav = document.querySelector('.admin-nav');
  if (adminNav) {
    const liveSupportButton = document.createElement('button');
    liveSupportButton.id = 'btnLiveSupport';
    liveSupportButton.innerHTML = '<i class="fas fa-headset"></i> Canlı Destek';
    liveSupportButton.addEventListener('click', function() {
      showAdminSection('sectionLiveSupport');
      
      // Bildirim rozetini kaldır
      const badge = liveSupportButton.querySelector('.notification-badge');
      if (badge) {
        badge.remove();
      }
      liveSupportButton.classList.remove('has-notification');
      liveSupportButton.classList.remove('pulse-animation');
    });
    
    const communityChatButton = document.createElement('button');
    communityChatButton.id = 'btnCommunityChat';
    communityChatButton.innerHTML = '<i class="fas fa-users"></i> Topluluk Sohbeti';
    communityChatButton.addEventListener('click', function() {
      showAdminSection('sectionCommunityChat');
    });
    
    adminNav.appendChild(liveSupportButton);
    adminNav.appendChild(communityChatButton);
  }
  
  // Canlı Destek bölümü oluştur
  const adminPanel = document.getElementById('adminPanel');
  if (adminPanel) {
    // Canlı Destek bölümü
    const liveSupportSection = document.createElement('div');
    liveSupportSection.id = 'sectionLiveSupport';
    liveSupportSection.className = 'admin-section';
    liveSupportSection.style.display = 'none';
    
    liveSupportSection.innerHTML = `
      <h2>Canlı Destek Yönetimi</h2>
      
      <div class="support-admin-container">
        <div class="support-admin-menu">
          <div class="menu-item active" data-target="dashboard">Dashboard</div>
          <div class="menu-item" data-target="agents">Temsilciler</div>
          <div class="menu-item" data-target="chats">Sohbetler</div>
          <div class="menu-item" data-target="responses">Hazır Yanıtlar</div>
          <div class="menu-item" data-target="settings">Ayarlar</div>
        </div>
        
        <div class="support-admin-content">
          <div id="supportDashboard" class="support-view">
            <h3>Canlı Destek Dashboard</h3>
            
            <div class="stats-container">
              <div class="stat-card">
                <h3>Aktif Temsilciler</h3>
                <div class="stat-value" id="activeAgentsCount">1</div>
              </div>
              
              <div class="stat-card">
                <h3>Aktif Sohbetler</h3>
                <div class="stat-value" id="activeChatsCount">0</div>
              </div>
              
              <div class="stat-card">
                <h3>Bekleyen Sohbetler</h3>
                <div class="stat-value" id="waitingChatsCount">0</div>
              </div>
              
              <div class="stat-card">
                <h3>Bugünkü Sohbetler</h3>
                <div class="stat-value" id="todayChatsCount">0</div>
              </div>
            </div>
            
            <div class="active-chats-list">
              <h3>Aktif Sohbetler</h3>
              <div class="list-container" id="activeChatsList">
                <div class="no-data">Aktif sohbet bulunmamaktadır.</div>
              </div>
            </div>
          </div>
          
          <div id="supportAgents" class="support-view" style="display: none;">
            <h3>Destek Temsilcileri</h3>
            
            <button class="add-agent-btn" id="addAgentBtn">Yeni Temsilci Ekle</button>
            
            <div class="agents-list" id="agentsList">
              <div class="agent-item">
                <div class="agent-info">
                  <div class="agent-name">Admin</div>
                  <div class="agent-email">admin@goldyatirim.com</div>
                  <div class="agent-title">Admin</div>
                </div>
                <div class="agent-status online">Çevrimiçi</div>
                <div class="agent-actions">
                  <button class="edit-btn">Düzenle</button>
                  <button class="delete-btn">Sil</button>
                </div>
              </div>
            </div>
          </div>
          
          <div id="supportChats" class="support-view" style="display: none;">
            <h3>Sohbetler</h3>
            
            <div class="chat-filters">
              <h4>Filtreler</h4>
              <div style="display: flex; gap: 10px; flex-wrap: wrap;">
                <div style="flex: 1; min-width: 200px;">
                  <label for="chatFilterDateFrom">Başlangıç Tarihi:</label>
                  <input type="date" id="chatFilterDateFrom" style="width: 100%; padding: 8px; box-sizing: border-box;">
                </div>
                <div style="flex: 1; min-width: 200px;">
                  <label for="chatFilterDateTo">Bitiş Tarihi:</label>
                  <input type="date" id="chatFilterDateTo" style="width: 100%; padding: 8px; box-sizing: border-box;">
                </div>
                <div style="flex: 1; min-width: 200px;">
                  <label for="chatFilterAgent">Temsilci:</label>
                  <select id="chatFilterAgent" style="width: 100%; padding: 8px; box-sizing: border-box;">
                    <option value="">Tümü</option>
                    <option value="admin">Admin</option>
                  </select>
                </div>
                <div style="flex: 1; min-width: 200px;">
                  <label for="chatFilterStatus">Durum:</label>
                  <select id="chatFilterStatus" style="width: 100%; padding: 8px; box-sizing: border-box;">
                    <option value="">Tümü</option>
                    <option value="active">Aktif</option>
                    <option value="ended">Sonlandırılmış</option>
                  </select>
                </div>
              </div>
              <button style="margin-top: 10px; padding: 8px 15px;">Filtrele</button>
            </div>
            
            <div class="chats-list">
              <div class="no-data">Sohbet kaydı bulunmamaktadır.</div>
            </div>
          </div>
          
          <div id="supportResponses" class="support-view" style="display: none;">
            <h3>Hazır Yanıtlar</h3>
            
            <div class="responses-view">
              <div class="response-categories">
                <h4>Kategoriler</h4>
                <div id="responseCategories">
                  <div class="response-category active">Karşılama</div>
                  <div class="response-category">Yatırım</div>
                  <div class="response-category">Para Yatırma</div>
                  <div class="response-category">Para Çekme</div>
                  <div class="response-category">Teknik</div>
                  <div class="response-category">Kapanış</div>
                </div>
                <button style="width: 100%; margin-top: 10px;">Yeni Kategori</button>
              </div>
              
              <div class="response-list">
                <h4>Yanıtlar - Karşılama</h4>
                <div id="responsesList">
                  <div style="border: 1px solid #ddd; padding: 10px; margin-bottom: 10px; border-radius: 4px;">
                    <div style="margin-bottom: 5px;">Merhaba, Gold Yatırım'a hoş geldiniz! Size nasıl yardımcı olabilirim?</div>
                    <div style="display: flex; justify-content: flex-end; gap: 5px;">
                      <button class="edit-btn">Düzenle</button>
                      <button class="delete-btn">Sil</button>
                    </div>
                  </div>
                  <div style="border: 1px solid #ddd; padding: 10px; margin-bottom: 10px; border-radius: 4px;">
                    <div style="margin-bottom: 5px;">Gold Yatırım destek ekibi olarak size nasıl yardımcı olabiliriz?</div>
                    <div style="display: flex; justify-content: flex-end; gap: 5px;">
                      <button class="edit-btn">Düzenle</button>
                      <button class="delete-btn">Sil</button>
                    </div>
                  </div>
                </div>
                <button style="margin-top: 10px;">Yeni Yanıt Ekle</button>
              </div>
            </div>
          </div>
          
          <div id="supportSettings" class="support-view" style="display: none;">
            <h3>Ayarlar</h3>
            
            <div class="settings-view">
              <div style="margin-bottom: 20px;">
                <h4>Karşılama Mesajı</h4>
                <textarea style="width: 100%; padding: 10px; height: 100px;">Merhaba, Gold Yatırım'a hoş geldiniz! Size nasıl yardımcı olabilirim?</textarea>
                <button style="margin-top: 10px;">Kaydet</button>
              </div>
              
              <div style="margin-bottom: 20px;">
                <h4>Çalışma Saatleri</h4>
                <div class="working-hours">
                  <div>
                    <label>Başlangıç:</label>
                    <input type="time" value="09:00">
                  </div>
                  <div>
                    <label>Bitiş:</label>
                    <input type="time" value="18:00">
                  </div>
                </div>
                <button style="margin-top: 10px;">Kaydet</button>
              </div>
              
              <div>
                <h4>Bildirim Sesi</h4>
                <select style="width: 100%; padding: 8px;">
                  <option value="default">Varsayılan</option>
                  <option value="bell">Zil</option>
                  <option value="chime">Çan</option>
                  <option value="notification">Bildirim</option>
                </select>
                <button style="margin-top: 10px;">Test Et</button>
                <button style="margin-top: 10px; margin-left: 10px;">Kaydet</button>
              </div>
            </div>
          </div>
        </div>
      </div>
    `;
    
    // Topluluk Sohbeti bölümü
    const communityChatSection = document.createElement('div');
    communityChatSection.id = 'sectionCommunityChat';
    communityChatSection.className = 'admin-section';
    communityChatSection.style.display = 'none';
    
    communityChatSection.innerHTML = `
      <h2>Topluluk Sohbeti Yönetimi</h2>
      
      <div class="community-admin-container">
        <div class="community-stats">
          <div class="stat-card">
            <h3>Aktif Kullanıcılar</h3>
            <div class="stat-value">0</div>
          </div>
          
          <div class="stat-card">
            <h3>Bugünkü Mesajlar</h3>
            <div class="stat-value">0</div>
          </div>
          
          <div class="stat-card">
            <h3>Toplam Mesajlar</h3>
            <div class="stat-value">0</div>
          </div>
        </div>
        
        <div class="community-messages">
          <h3>Topluluk Mesajları</h3>
          
          <div class="messages-container" id="communityMessagesList">
            <div class="no-data">Henüz mesaj bulunmamaktadır.</div>
          </div>
          
          <div class="admin-message-form">
            <h4>Admin Mesajı Gönder</h4>
            <textarea style="width: 100%; padding: 10px; height: 100px;" placeholder="Mesajınızı yazın..."></textarea>
            <button style="margin-top: 10px;">Gönder</button>
          </div>
        </div>
        
        <div class="community-settings">
          <h3>Topluluk Sohbeti Ayarları</h3>
          
          <div style="margin-bottom: 20px;">
            <h4>Durum</h4>
            <div style="display: flex; align-items: center; gap: 10px;">
              <label>
                <input type="checkbox" checked> Topluluk sohbetini aktif et
              </label>
            </div>
          </div>
          
          <div style="margin-bottom: 20px;">
            <h4>Mesaj Ömrü</h4>
            <div style="display: flex; align-items: center; gap: 10px;">
              <input type="number" value="45" style="width: 80px; padding: 8px;"> dakika
            </div>
            <p style="color: #666; font-size: 0.9em;">Mesajlar belirtilen süre sonunda otomatik olarak silinir.</p>
          </div>
          
          <button>Ayarları Kaydet</button>
        </div>
      </div>
    `;
    
    adminPanel.appendChild(liveSupportSection);
    adminPanel.appendChild(communityChatSection);
    
    // Admin paneli menü işlevleri
    document.querySelectorAll('.support-admin-menu .menu-item').forEach(item => {
      item.addEventListener('click', function() {
        const target = this.getAttribute('data-target');
        
        // Menü öğelerini güncelle
        document.querySelectorAll('.support-admin-menu .menu-item').forEach(menuItem => {
          menuItem.classList.remove('active');
        });
        this.classList.add('active');
        
        // İlgili görünümü göster
        document.querySelectorAll('.support-view').forEach(view => {
          view.style.display = 'none';
        });
        document.getElementById('support' + target.charAt(0).toUpperCase() + target.slice(1)).style.display = 'block';
      });
    });
  }
}

// Admin paneli bölümlerini göster/gizle
function showAdminSection(sectionId) {
  // Tüm bölümleri gizle
  document.querySelectorAll('.admin-section').forEach(section => {
    section.style.display = 'none';
  });
  
  // Tüm butonların aktif sınıfını kaldır
  document.querySelectorAll('.admin-nav button').forEach(button => {
    button.classList.remove('active');
  });
  
  // İlgili bölümü göster
  document.getElementById(sectionId).style.display = 'block';
  
  // İlgili butonu aktif yap
  if (sectionId === 'sectionLiveSupport') {
    document.getElementById('btnLiveSupport').classList.add('active');
  } else if (sectionId === 'sectionCommunityChat') {
    document.getElementById('btnCommunityChat').classList.add('active');
  }
}
