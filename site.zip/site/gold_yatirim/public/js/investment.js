document.addEventListener('DOMContentLoaded', () => {
  const buyButtons = document.querySelectorAll('.buy-btn');
  const toggleLockdaysButtons = document.querySelectorAll('.toggle-lockdays-btn');

  toggleLockdaysButtons.forEach(btn => {
    btn.addEventListener('click', () => {
      const investmentBox = btn.closest('.investment-box');
      const lockdaysTabs = investmentBox.querySelector('.lockdays-tabs');
      if (lockdaysTabs.style.display === 'none' || lockdaysTabs.style.display === '') {
        lockdaysTabs.style.display = 'flex';
      } else {
        lockdaysTabs.style.display = 'none';
      }
    });
  });

  // Yatırım seçeneklerini yükle
  async function loadInvestmentOptions() {
    try {
      const response = await fetch('/investment/options');
      if (!response.ok) {
        throw new Error('Yatırım seçenekleri yüklenemedi');
      }
      const options = await response.json();
      
      // Yatırım seçeneklerini güncelle
      options.forEach(option => {
        const investmentBox = document.querySelector(`.investment-box[data-index="${option.id}"]`);
        if (investmentBox) {
          const stockElement = investmentBox.querySelector('.stock');
          if (stockElement) {
            stockElement.textContent = option.stockControl || 10;
          }
        }
      });
    } catch (error) {
      console.error('Yatırım seçenekleri yüklenirken hata:', error);
    }
  }
  
  // Sayfa yüklendiğinde yatırım seçeneklerini yükle
  loadInvestmentOptions();

  buyButtons.forEach((btn, index) => {
    const investmentBox = btn.closest('.investment-box');
    const stockElement = investmentBox.querySelector('.stock');
    const countdownElement = investmentBox.querySelector('.countdown');
    const tabButtons = investmentBox.querySelectorAll('.tab-btn');

    // Varsayılan stok ve kilitleme süresi
    let stock = parseInt(stockElement.textContent, 10);
    let selectedLockDays = 7;
    let selectedYield = 7;
    
    // Stok kontrolü
    function updateButtonState() {
      if (stock <= 0) {
        btn.disabled = true;
        btn.textContent = 'Stokta Yok';
        btn.style.backgroundColor = '#999';
      } else {
        btn.disabled = false;
        btn.textContent = 'Satın Al';
        btn.style.backgroundColor = '';
      }
    }
    
    updateButtonState();

    // Tab butonları için event listener
    tabButtons.forEach(tab => {
      tab.addEventListener('click', () => {
        tabButtons.forEach(t => t.classList.remove('active'));
        tab.classList.add('active');
        selectedLockDays = parseInt(tab.dataset.value, 10);
        selectedYield = tab.dataset.rate;
        updateCountdown();
        updateYield();
      });
    });

    // Geri sayım fonksiyonu (örnek olarak sabit tarih değil, sadece kilitleme süresi gösteriliyor)
    function updateCountdown() {
      countdownElement.textContent = `${selectedLockDays} gün kilit süresi`;
    }

    function updateYield() {
      const yieldElement = investmentBox.querySelector('.yield');
      yieldElement.textContent = `${selectedYield}%`;
    }

    updateCountdown();
    updateYield();


    // Satın alma butonuna tıklama
    btn.addEventListener('click', () => {
      if (stock <= 0) {
        alert('Bu yatırım paketi stokta kalmamıştır.');
        return;
      }

      const priceElement = investmentBox.querySelector('.price');
      const price = parseFloat(priceElement.textContent.replace(' USDT', ''));
      
      // Satın alma işlemi
      fetch('/investment/create', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          investmentId: index + 1,
          usdtAmount: price,
          lockDays: selectedLockDays
        }),
      })
        .then(res => res.json())
        .then(data => {
          if (data.message && data.investment) {
            alert('Yatırım başarıyla satın alındı!');
            stock -= 1;
            stockElement.textContent = stock;
            
            // Yatırım başarılı olduğunda profil sayfasına yönlendir
            setTimeout(() => {
              window.location.href = '/profile';
            }, 1500);
          } else {
            alert('Satın alma işlemi başarısız: ' + (data.error || 'Bilinmeyen hata'));
          }
        })
        .catch(() => {
          alert('Satın alma işlemi sırasında hata oluştu.');
        });
    });
  });
});
