document.addEventListener('DOMContentLoaded', () => {
  // Topluluk Sohbeti Sistemi
  class CommunityChatSystem {
    constructor() {
      this.messages = [];
      this.messageLifetime = 45 * 60 * 1000; // 45 dakika (milisaniye cinsinden)
      this.enabled = true;
      this.init();
    }
    
    init() {
      this.loadMessages();
      this.createChatUI();
      this.startMessageCleanup();
    }
    
    // Mesajları yükleme
    loadMessages() {
      const savedMessages = localStorage.getItem('communityChat_messages');
      if (savedMessages) {
        this.messages = JSON.parse(savedMessages);
      }
    }
    
    // Mesajları kaydetme
    saveMessages() {
      localStorage.setItem('communityChat_messages', JSON.stringify(this.messages));
    }
    
    // Mesaj temizleme işlemini başlat
    startMessageCleanup() {
      setInterval(() => {
        this.cleanupExpiredMessages();
      }, 60000); // Her dakika kontrol et
    }
    
    // Süresi dolmuş mesajları temizle
    cleanupExpiredMessages() {
      const now = new Date();
      const initialCount = this.messages.length;
      
      this.messages = this.messages.filter(msg => {
        return new Date(msg.expiresAt) > now;
      });
      
      if (initialCount !== this.messages.length) {
        this.saveMessages();
        
        // Eğer sohbet penceresi açıksa, mesajları güncelle
        const chatWindow = document.getElementById('community-chat-window');
        if (chatWindow && window.getComputedStyle(chatWindow).display !== 'none') {
          this.renderMessages();
        }
      }
    }
    
    // Yeni mesaj ekleme
    addMessage(messageData) {
      const now = new Date();
      const expiresAt = new Date(now.getTime() + this.messageLifetime);
      
      const message = {
        id: `msg_${Date.now()}`,
        content: messageData.content,
        userId: messageData.userId || `user_${Date.now().toString(36)}`,
        userType: messageData.userType || 'user',
        timestamp: now,
        expiresAt: expiresAt
      };
      
      this.messages.push(message);
      this.saveMessages();
      
      // Eğer sohbet penceresi açıksa, mesajları güncelle
      const chatWindow = document.getElementById('community-chat-window');
      if (chatWindow && window.getComputedStyle(chatWindow).display !== 'none') {
        this.renderMessages();
      }
      
      return message;
    }
    
    // Kullanıcı adını maskeleme
    maskUsername(userId) {
      if (userId === 'admin') return 'Admin';
      
      // Kullanıcı ID'sini kısalt ve yarısını maskele
      const shortId = userId.replace('user_', '').substring(0, 6);
      const halfLength = Math.ceil(shortId.length / 2);
      const visiblePart = shortId.substring(0, halfLength);
      const maskedPart = '*'.repeat(shortId.length - halfLength);
      
      return `Kullanıcı #${visiblePart}${maskedPart}`;
    }
    
    // Topluluk sohbeti arayüzü oluşturma
    createChatUI() {
      // Sohbet butonu
      const chatButton = document.createElement('div');
      chatButton.id = 'community-chat-button';
      chatButton.innerHTML = '<i class="fas fa-users"></i> Topluluk Sohbeti';
      chatButton.style.position = 'fixed';
      chatButton.style.bottom = '20px';
      chatButton.style.right = '180px';
      chatButton.style.backgroundColor = '#0f0f3f';
      chatButton.style.color = '#00ffe5';
      chatButton.style.padding = '10px 20px';
      chatButton.style.borderRadius = '30px';
      chatButton.style.cursor = 'pointer';
      chatButton.style.boxShadow = '0 2px 10px rgba(0, 0, 0, 0.2)';
      chatButton.style.zIndex = '9998';
      chatButton.style.fontWeight = 'bold';
      
      chatButton.addEventListener('click', () => {
        this.toggleChatWindow();
      });
      
      document.body.appendChild(chatButton);
      
      // Eğer topluluk sohbeti devre dışı bırakıldıysa butonu gizle
      if (!this.enabled) {
        chatButton.style.display = 'none';
      }
    }
    
    // Sohbet penceresini aç/kapat
    toggleChatWindow() {
      let chatWindow = document.getElementById('community-chat-window');
      
      if (chatWindow) {
        chatWindow.remove();
      } else {
        this.showChatWindow();
      }
    }
    
    // Sohbet penceresini göster
    showChatWindow() {
      const chatWindow = document.createElement('div');
      chatWindow.id = 'community-chat-window';
      chatWindow.style.position = 'fixed';
      chatWindow.style.bottom = '80px';
      chatWindow.style.right = '180px';
      chatWindow.style.width = '350px';
      chatWindow.style.height = '500px';
      chatWindow.style.backgroundColor = '#fff';
      chatWindow.style.borderRadius = '10px';
      chatWindow.style.boxShadow = '0 5px 25px rgba(0, 0, 0, 0.2)';
      chatWindow.style.zIndex = '9999';
      chatWindow.style.display = 'flex';
      chatWindow.style.flexDirection = 'column';
      chatWindow.style.overflow = 'hidden';
      
      // Başlık
      const header = document.createElement('div');
      header.style.backgroundColor = '#0f0f3f';
      header.style.color = '#00ffe5';
      header.style.padding = '15px';
      header.style.fontWeight = 'bold';
      header.style.display = 'flex';
      header.style.justifyContent = 'space-between';
      header.style.alignItems = 'center';
      
      const headerTitle = document.createElement('div');
      headerTitle.textContent = 'Gold Yatırım Topluluk Sohbeti';
      
      const closeButton = document.createElement('div');
      closeButton.textContent = '✖';
      closeButton.style.cursor = 'pointer';
      
      closeButton.addEventListener('click', () => {
        chatWindow.remove();
      });
      
      header.appendChild(headerTitle);
      header.appendChild(closeButton);
      
      // Mesaj alanı
      const messagesContainer = document.createElement('div');
      messagesContainer.id = 'community-chat-messages';
      messagesContainer.style.flex = '1';
      messagesContainer.style.overflowY = 'auto';
      messagesContainer.style.padding = '15px';
      messagesContainer.style.display = 'flex';
      messagesContainer.style.flexDirection = 'column-reverse';
      
      // Mesaj giriş alanı
      const inputContainer = document.createElement('div');
      inputContainer.style.borderTop = '1px solid #eee';
      inputContainer.style.padding = '15px';
      inputContainer.style.display = 'flex';
      
      const messageInput = document.createElement('input');
      messageInput.type = 'text';
      messageInput.id = 'community-chat-input';
      messageInput.placeholder = 'Mesajınızı yazın...';
      messageInput.style.flex = '1';
      messageInput.style.padding = '10px';
      messageInput.style.border = '1px solid #ddd';
      messageInput.style.borderRadius = '4px';
      messageInput.style.marginRight = '10px';
      
      const sendButton = document.createElement('button');
      sendButton.textContent = 'Gönder';
      sendButton.style.backgroundColor = '#0f0f3f';
      sendButton.style.color = '#00ffe5';
      sendButton.style.border = 'none';
      sendButton.style.borderRadius = '4px';
      sendButton.style.padding = '10px 15px';
      sendButton.style.cursor = 'pointer';
      
      // Mesaj gönderme işlevi
      const sendMessage = () => {
        const content = messageInput.value.trim();
        if (content) {
          this.addMessage({
            content,
            userId: `user_${Date.now().toString(36)}`,
            userType: 'user'
          });
          messageInput.value = '';
        }
      };
      
      sendButton.addEventListener('click', sendMessage);
      
      messageInput.addEventListener('keypress', (e) => {
        if (e.key === 'Enter') {
          sendMessage();
        }
      });
      
      inputContainer.appendChild(messageInput);
      inputContainer.appendChild(sendButton);
      
      // Bilgi metni
      const infoText = document.createElement('div');
      infoText.style.padding = '10px 15px';
      infoText.style.backgroundColor = '#f9f9f9';
      infoText.style.borderTop = '1px solid #eee';
      infoText.style.fontSize = '0.8em';
      infoText.style.color = '#666';
      infoText.textContent = `Not: Mesajlar ${this.messageLifetime / (60 * 1000)} dakika sonra otomatik olarak silinir.`;
      
      // Bileşenleri bir araya getir
      chatWindow.appendChild(header);
      chatWindow.appendChild(messagesContainer);
      chatWindow.appendChild(inputContainer);
      chatWindow.appendChild(infoText);
      
      document.body.appendChild(chatWindow);
      
      // Mesajları yükle
      this.renderMessages();
      
      // Input'a odaklan
      messageInput.focus();
    }
    
    // Mesajları render et
    renderMessages() {
      const messagesContainer = document.getElementById('community-chat-messages');
      if (!messagesContainer) return;
      
      messagesContainer.innerHTML = '';
      
      // Mesajları tarih sırasına göre sırala (en yeniler altta)
      const sortedMessages = [...this.messages].sort((a, b) => 
        new Date(a.timestamp) - new Date(b.timestamp)
      );
      
      if (sortedMessages.length === 0) {
        const emptyMessage = document.createElement('div');
        emptyMessage.style.textAlign = 'center';
        emptyMessage.style.padding = '20px';
        emptyMessage.style.color = '#999';
        emptyMessage.style.fontStyle = 'italic';
        emptyMessage.textContent = 'Henüz mesaj bulunmamaktadır. İlk mesajı siz gönderin!';
        messagesContainer.appendChild(emptyMessage);
        return;
      }
      
      sortedMessages.forEach(msg => {
        const messageEl = document.createElement('div');
        messageEl.className = 'community-chat-message';
        messageEl.style.marginBottom = '15px';
        messageEl.style.padding = '10px';
        messageEl.style.borderRadius = '5px';
        messageEl.style.maxWidth = '80%';
        messageEl.style.wordBreak = 'break-word';
        
        // Admin mesajları için farklı stil
        if (msg.userType === 'admin') {
          messageEl.style.backgroundColor = '#0f0f3f';
          messageEl.style.color = '#fff';
          messageEl.style.alignSelf = 'center';
          messageEl.style.width = '90%';
          messageEl.style.borderLeft = '4px solid #00ffe5';
        } else {
          messageEl.style.backgroundColor = '#f0f0f0';
          messageEl.style.alignSelf = 'flex-start';
        }
        
        const messageContent = document.createElement('div');
        messageContent.textContent = msg.content;
        
        const messageInfo = document.createElement('div');
        messageInfo.style.fontSize = '0.8em';
        messageInfo.style.marginTop = '5px';
        messageInfo.style.color = msg.userType === 'admin' ? '#aaa' : '#999';
        
        const username = this.maskUsername(msg.userId);
        const time = new Date(msg.timestamp).toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' });
        
        messageInfo.textContent = `${username} • ${time}`;
        
        messageEl.appendChild(messageContent);
        messageEl.appendChild(messageInfo);
        
        messagesContainer.appendChild(messageEl);
      });
      
      // Otomatik kaydırma
      messagesContainer.scrollTop = messagesContainer.scrollHeight;
    }
  }
  
  // Topluluk sohbeti sistemini başlat
  window.communityChatSystem = new CommunityChatSystem();
});
