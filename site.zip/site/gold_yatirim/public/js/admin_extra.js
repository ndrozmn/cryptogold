// Bu dosya artık kullanılmıyor. Tüm işlevsellik admin.js dosyasına taşındı.
// Geriye dönük uyumluluk için korunmuştur.
