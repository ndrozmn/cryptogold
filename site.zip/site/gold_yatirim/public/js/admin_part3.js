document.addEventListener('DOMContentLoaded', () => {
  // DOM Elemanları
  const withdrawalRequests = document.getElementById('withdrawalRequests');
  const depositRequests = document.getElementById('depositRequests');

  // Durum metni döndür
  function getStatusText(status) {
    switch (status) {
      case 'pending': return 'İşleminiz İnceleniyor';
      case 'approved': return 'Onaylandı';
      case 'rejected': return 'Reddedildi';
      default: return status;
    }
  }

  // Para yatırma taleplerini yükle ve listele
  async function loadDepositRequests() {
    try {
      const res = await fetch('/admin/deposit-requests');
      if (!res.ok) {
        throw new Error('Para yatırma talepleri yüklenemedi');
      }
      const requests = await res.json();
      displayDepositRequests(requests);
    } catch (error) {
      console.error('Para yatırma talepleri yüklenirken hata:', error);
    }
  }

  // Para yatırma taleplerini göster
  function displayDepositRequests(requests) {
    depositRequests.innerHTML = '';
    
    if (requests.length === 0) {
      depositRequests.innerHTML = '<p>Bekleyen para yatırma talebi bulunmamaktadır.</p>';
      return;
    }
    
    const table = document.createElement('table');
    table.className = 'admin-table';
    
    // Tablo başlığı
    const thead = document.createElement('thead');
    const headerRow = document.createElement('tr');
    ['Kullanıcı', 'Miktar', 'TRON İşlem ID', 'Tarih', 'Durum', 'İşlemler'].forEach(text => {
      const th = document.createElement('th');
      th.textContent = text;
      headerRow.appendChild(th);
    });
    thead.appendChild(headerRow);
    table.appendChild(thead);
    
    // Tablo gövdesi
    const tbody = document.createElement('tbody');
    requests.forEach(req => {
      const tr = document.createElement('tr');
      
      // Kullanıcı
      const userTd = document.createElement('td');
      userTd.textContent = req.user && req.user.username ? req.user.username : req.user;
      tr.appendChild(userTd);
      
      // Miktar
      const amountTd = document.createElement('td');
      amountTd.textContent = `${req.amount || '0'} USDT`;
      tr.appendChild(amountTd);
      
      // TRON İşlem ID
      const tronTxIdTd = document.createElement('td');
      const tronTxIdContainer = document.createElement('div');
      tronTxIdContainer.style.display = 'flex';
      tronTxIdContainer.style.alignItems = 'center';
      
      const tronTxIdInput = document.createElement('input');
      tronTxIdInput.type = 'text';
      tronTxIdInput.value = req.tronTransactionId || 'Belirtilmemiş';
      tronTxIdInput.readOnly = true;
      tronTxIdInput.className = 'tron-input';
      
      const copyBtn = document.createElement('button');
      copyBtn.textContent = 'Kopyala';
      copyBtn.className = 'copy-btn';
      copyBtn.addEventListener('click', () => {
        navigator.clipboard.writeText(tronTxIdInput.value)
          .then(() => {
            alert('TRON işlem ID kopyalandı!');
          })
          .catch(() => {
            alert('Kopyalama işlemi başarısız oldu.');
          });
      });
      
      tronTxIdContainer.appendChild(tronTxIdInput);
      tronTxIdContainer.appendChild(copyBtn);
      tronTxIdTd.appendChild(tronTxIdContainer);
      tr.appendChild(tronTxIdTd);
      
      // Tarih
      const dateTd = document.createElement('td');
      dateTd.textContent = new Date(req.createdAt || Date.now()).toLocaleDateString();
      tr.appendChild(dateTd);
      
      // Durum
      const statusTd = document.createElement('td');
      const statusSpan = document.createElement('span');
      statusSpan.className = `status ${req.status || 'pending'}`;
      statusSpan.textContent = getStatusText(req.status || 'pending');
      statusTd.appendChild(statusSpan);
      tr.appendChild(statusTd);
      
      // İşlemler
      const actionsTd = document.createElement('td');
      actionsTd.className = 'action-buttons';
      
      // Onayla butonu
      const approveBtn = document.createElement('button');
      approveBtn.textContent = 'Onayla';
      approveBtn.className = 'approve-btn';
      approveBtn.addEventListener('click', () => {
        if (confirm('Bu para yatırma talebini onaylamak istiyor musunuz?')) {
          approveDeposit(req._id);
        }
      });
      actionsTd.appendChild(approveBtn);
      
      // Reddet butonu
      const rejectBtn = document.createElement('button');
      rejectBtn.textContent = 'Reddet';
      rejectBtn.className = 'reject-btn';
      rejectBtn.addEventListener('click', () => {
        if (confirm('Bu para yatırma talebini reddetmek istiyor musunuz?')) {
          rejectDeposit(req._id);
        }
      });
      actionsTd.appendChild(rejectBtn);
      
      tr.appendChild(actionsTd);
      tbody.appendChild(tr);
    });
    
    table.appendChild(tbody);
    depositRequests.appendChild(table);
  }

  // Para yatırma talebini onayla
  async function approveDeposit(depositId) {
    try {
      const res = await fetch(`/admin/deposit-requests/${depositId}/approve`, {
        method: 'POST'
      });
      if (res.ok) {
        alert('Para yatırma talebi onaylandı');
        loadDepositRequests();
      } else {
        alert('Para yatırma talebi onaylanırken hata oluştu');
      }
    } catch (error) {
      console.error('Para yatırma onaylama hatası:', error);
    }
  }

  // Para yatırma talebini reddet
  async function rejectDeposit(depositId) {
    try {
      const res = await fetch(`/admin/deposit-requests/${depositId}/reject`, {
        method: 'POST'
      });
      if (res.ok) {
        alert('Para yatırma talebi reddedildi');
        loadDepositRequests();
      } else {
        alert('Para yatırma talebi reddedilirken hata oluştu');
      }
    } catch (error) {
      console.error('Para yatırma reddetme hatası:', error);
    }
  }

  // Para çekme taleplerini yükle ve listele
  async function loadWithdrawalRequests() {
    try {
      const res = await fetch('/admin/withdrawal-requests');
      if (!res.ok) {
        throw new Error('Para çekme talepleri yüklenemedi');
      }
      const requests = await res.json();
      displayWithdrawalRequests(requests);
    } catch (error) {
      console.error('Para çekme talepleri yüklenirken hata:', error);
    }
  }

  // Para çekme taleplerini göster
  function displayWithdrawalRequests(requests) {
    withdrawalRequests.innerHTML = '';
    
    if (requests.length === 0) {
      withdrawalRequests.innerHTML = '<p>Bekleyen para çekme talebi bulunmamaktadır.</p>';
      return;
    }
    
    const table = document.createElement('table');
    table.className = 'admin-table';
    
    // Tablo başlığı
    const thead = document.createElement('thead');
    const headerRow = document.createElement('tr');
    ['Kullanıcı', 'Miktar', 'Net Miktar', 'TRON Ağı Adresi', 'Tarih', 'Durum', 'İşlemler'].forEach(text => {
      const th = document.createElement('th');
      th.textContent = text;
      headerRow.appendChild(th);
    });
    thead.appendChild(headerRow);
    table.appendChild(thead);
    
    // Tablo gövdesi
    const tbody = document.createElement('tbody');
    requests.forEach(req => {
      const tr = document.createElement('tr');
      
      // Kullanıcı
      const userTd = document.createElement('td');
      userTd.textContent = req.user && req.user.username ? req.user.username : req.user;
      tr.appendChild(userTd);
      
      // Miktar
      const amountTd = document.createElement('td');
      amountTd.textContent = `${req.amount || '0'} USDT`;
      tr.appendChild(amountTd);
      
      // Net Miktar (komisyon düşülmüş)
      const netAmountTd = document.createElement('td');
      const netAmount = req.netAmount || (req.amount * 0.95);
      netAmountTd.textContent = `${netAmount.toFixed(2)} USDT`;
      tr.appendChild(netAmountTd);
      
      // TRON Ağı Adresi
      const tronAddressTd = document.createElement('td');
      const tronAddressContainer = document.createElement('div');
      tronAddressContainer.style.display = 'flex';
      tronAddressContainer.style.alignItems = 'center';
      
      const tronAddressInput = document.createElement('input');
      tronAddressInput.type = 'text';
      tronAddressInput.value = req.tronWalletAddress || 'Belirtilmemiş';
      tronAddressInput.readOnly = true;
      tronAddressInput.className = 'tron-input';
      
      const copyBtn = document.createElement('button');
      copyBtn.textContent = 'Kopyala';
      copyBtn.className = 'copy-btn';
      copyBtn.addEventListener('click', () => {
        navigator.clipboard.writeText(tronAddressInput.value)
          .then(() => {
            alert('TRON adresi kopyalandı!');
          })
          .catch(() => {
            alert('Kopyalama işlemi başarısız oldu.');
          });
      });
      
      tronAddressContainer.appendChild(tronAddressInput);
      tronAddressContainer.appendChild(copyBtn);
      tronAddressTd.appendChild(tronAddressContainer);
      tr.appendChild(tronAddressTd);
      
      // Tarih
      const dateTd = document.createElement('td');
      dateTd.textContent = new Date(req.createdAt || Date.now()).toLocaleDateString();
      tr.appendChild(dateTd);
      
      // Durum
      const statusTd = document.createElement('td');
      const statusSpan = document.createElement('span');
      statusSpan.className = `status ${req.status || 'pending'}`;
      statusSpan.textContent = getStatusText(req.status || 'pending');
      statusTd.appendChild(statusSpan);
      tr.appendChild(statusTd);
      
      // İşlemler
      const actionsTd = document.createElement('td');
      actionsTd.className = 'action-buttons';
      
      // Onayla butonu
      const approveBtn = document.createElement('button');
      approveBtn.textContent = 'Onayla';
      approveBtn.className = 'approve-btn';
      approveBtn.addEventListener('click', () => {
        if (confirm('Bu para çekme talebini onaylamak istiyor musunuz?')) {
          approveWithdrawal(req._id);
        }
      });
      actionsTd.appendChild(approveBtn);
      
      // Reddet butonu
      const rejectBtn = document.createElement('button');
      rejectBtn.textContent = 'Reddet';
      rejectBtn.className = 'reject-btn';
      rejectBtn.addEventListener('click', () => {
        if (confirm('Bu para çekme talebini reddetmek istiyor musunuz?')) {
          rejectWithdrawal(req._id);
        }
      });
      actionsTd.appendChild(rejectBtn);
      
      // İşlem ID Ekle butonu
      const addTxIdBtn = document.createElement('button');
      addTxIdBtn.textContent = 'İşlem ID Ekle';
      addTxIdBtn.className = 'txid-btn';
      addTxIdBtn.addEventListener('click', () => {
        const txId = prompt('TRON işlem ID\'sini girin:');
        if (txId) {
          updateWithdrawalTxId(req._id, txId);
        }
      });
      actionsTd.appendChild(addTxIdBtn);
      
      tr.appendChild(actionsTd);
      tbody.appendChild(tr);
    });
    
    table.appendChild(tbody);
    withdrawalRequests.appendChild(table);
  }

  // Para çekme talebini onayla
  async function approveWithdrawal(withdrawalId) {
    try {
      const res = await fetch(`/admin/withdrawal-requests/${withdrawalId}/approve`, {
        method: 'POST'
      });
      if (res.ok) {
        alert('Para çekme talebi onaylandı');
        loadWithdrawalRequests();
      } else {
        alert('Para çekme talebi onaylanırken hata oluştu');
      }
    } catch (error) {
      console.error('Para çekme onaylama hatası:', error);
    }
  }

  // Para çekme talebini reddet
  async function rejectWithdrawal(withdrawalId) {
    try {
      const res = await fetch(`/admin/withdrawal-requests/${withdrawalId}/reject`, {
        method: 'POST'
      });
      if (res.ok) {
        alert('Para çekme talebi reddedildi');
        loadWithdrawalRequests();
      } else {
        alert('Para çekme talebi reddedilirken hata oluştu');
      }
    } catch (error) {
      console.error('Para çekme reddetme hatası:', error);
    }
  }

  // Para çekme işlem ID'sini güncelle
  async function updateWithdrawalTxId(withdrawalId, txId) {
    try {
      const res = await fetch(`/admin/withdrawal-requests/${withdrawalId}/update-txid`, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ txId })
      });
      if (res.ok) {
        alert('İşlem ID güncellendi');
        loadWithdrawalRequests();
      } else {
        alert('İşlem ID güncellenirken hata oluştu');
      }
    } catch (error) {
      console.error('İşlem ID güncelleme hatası:', error);
    }
  }

  // Fonksiyonları global olarak tanımla
  window.loadDepositRequests = loadDepositRequests;
  window.loadWithdrawalRequests = loadWithdrawalRequests;
});
