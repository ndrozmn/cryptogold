document.addEventListener('DOMContentLoaded', () => {
  // DOM Elemanları
  const searchInput = document.getElementById('searchInput');
  const userList = document.getElementById('userList').getElementsByTagName('tbody')[0];
  const investmentRequests = document.getElementById('investmentRequests');
  const withdrawalRequests = document.getElementById('withdrawalRequests');
  const depositRequests = document.getElementById('depositRequests');
  const investmentEditFormContainer = document.getElementById('investmentEditFormContainer');
  const editInvestmentId = document.getElementById('editInvestmentId');
  const editStockControl = document.getElementById('editStockControl');
  const editPrice = document.getElementById('editPrice');
  const editEarnings = document.getElementById('editEarnings');
  const editPercentage = document.getElementById('editPercentage');
  const cancelEditInvestment = document.getElementById('cancelEditInvestment');
  const investmentEditForm = document.getElementById('investmentEditForm');
  const investmentSettingsTable = document.getElementById('investmentSettingsTable').getElementsByTagName('tbody')[0];
  
  // Menü butonları
  const btnUsers = document.getElementById('btnUsers');
  const btnWithdrawalRequests = document.getElementById('btnWithdrawalRequests');
  const btnDepositRequests = document.getElementById('btnDepositRequests');
  const btnInvestmentRequests = document.getElementById('btnInvestmentRequests');
  const btnInvestmentSettings = document.getElementById('btnInvestmentSettings');
  
  // Bölümler
  const sectionUsers = document.getElementById('sectionUsers');
  const sectionWithdrawalRequests = document.getElementById('sectionWithdrawalRequests');
  const sectionDepositRequests = document.getElementById('sectionDepositRequests');
  const sectionInvestmentRequests = document.getElementById('sectionInvestmentRequests');
  const sectionInvestmentSettings = document.getElementById('sectionInvestmentSettings');

  // Menü butonlarına tıklama olayları
  btnUsers.addEventListener('click', () => {
    showSection('sectionUsers');
    setActiveButton(btnUsers);
  });
  
  btnWithdrawalRequests.addEventListener('click', () => {
    showSection('sectionWithdrawalRequests');
    setActiveButton(btnWithdrawalRequests);
    loadWithdrawalRequests();
  });
  
  btnDepositRequests.addEventListener('click', () => {
    showSection('sectionDepositRequests');
    setActiveButton(btnDepositRequests);
    loadDepositRequests();
  });
  
  btnInvestmentRequests.addEventListener('click', () => {
    showSection('sectionInvestmentRequests');
    setActiveButton(btnInvestmentRequests);
    loadInvestmentRequests();
  });
  
  btnInvestmentSettings.addEventListener('click', () => {
    showSection('sectionInvestmentSettings');
    setActiveButton(btnInvestmentSettings);
    loadInvestmentSettings();
  });

  // Aktif butonu ayarla
  function setActiveButton(activeButton) {
    // Tüm butonlardan active sınıfını kaldır
    [btnUsers, btnWithdrawalRequests, btnDepositRequests, btnInvestmentRequests, btnInvestmentSettings].forEach(btn => {
      btn.classList.remove('active');
    });
    
    // Aktif butona active sınıfını ekle
    activeButton.classList.add('active');
  }

  // Durum metni döndür
  function getStatusText(status) {
    switch (status) {
      case 'pending': return 'Beklemede';
      case 'approved': return 'Onaylandı';
      case 'rejected': return 'Reddedildi';
      default: return status;
    }
  }

  // Sayfa bölümlerini kontrol et
  function showSection(sectionId) {
    // Tüm bölümleri gizle
    sectionUsers.style.display = 'none';
    sectionWithdrawalRequests.style.display = 'none';
    sectionDepositRequests.style.display = 'none';
    sectionInvestmentRequests.style.display = 'none';
    sectionInvestmentSettings.style.display = 'none';
    
    // İstenen bölümü göster
    document.getElementById(sectionId).style.display = 'block';
  }

  // Kullanıcı silme fonksiyonu
  async function deleteUser(userId) {
    try {
      const res = await fetch(`/admin/users/${userId}`, { method: 'DELETE' });
      if (res.ok) {
        alert('Kullanıcı silindi');
        loadUsers();
      } else {
        alert('Kullanıcı silinirken hata oluştu');
      }
    } catch (error) {
      console.error('Kullanıcı silme hatası:', error);
    }
  }

  // Şifre sıfırlama fonksiyonu
  async function resetPassword(userId) {
    try {
      const res = await fetch(`/admin/users/${userId}/reset-password`, { method: 'POST' });
      if (res.ok) {
        alert('Şifre sıfırlama işlemi başarılı');
      } else {
        alert('Şifre sıfırlama işlemi başarısız');
      }
    } catch (error) {
      console.error('Şifre sıfırlama hatası:', error);
    }
  }

  // Kullanıcıları yükle
  async function loadUsers() {
    try {
      const res = await fetch('/admin/users');
      if (!res.ok) {
        throw new Error('Kullanıcılar yüklenemedi');
      }
      const users = await res.json();
      displayUsers(users);
    } catch (error) {
      console.error('Kullanıcılar yüklenirken hata:', error);
    }
  }

  // Kullanıcıları tabloya ekle
  function displayUsers(users) {
    userList.innerHTML = '';
    
    if (users.length === 0) {
      const tr = document.createElement('tr');
      const td = document.createElement('td');
      td.colSpan = 4;
      td.textContent = 'Kullanıcı bulunamadı';
      td.style.textAlign = 'center';
      tr.appendChild(td);
      userList.appendChild(tr);
      return;
    }
    
    users.forEach(user => {
      const tr = document.createElement('tr');

      const usernameTd = document.createElement('td');
      usernameTd.textContent = user.username || '';
      tr.appendChild(usernameTd);

      const emailTd = document.createElement('td');
      emailTd.textContent = user.email || '';
      tr.appendChild(emailTd);

      const balanceTd = document.createElement('td');
      balanceTd.textContent = user.balance !== undefined ? `${user.balance} USDT` : '0 USDT';
      tr.appendChild(balanceTd);

      const actionsTd = document.createElement('td');

      // Şifre sıfırlama butonu
      const resetBtn = document.createElement('button');
      resetBtn.textContent = 'Şifre Sıfırla';
      resetBtn.addEventListener('click', () => {
        if (confirm(`"${user.username}" kullanıcısının şifresi sıfırlansın mı?`)) {
          resetPassword(user._id);
        }
      });
      actionsTd.appendChild(resetBtn);

      // Kullanıcı silme butonu
      const deleteBtn = document.createElement('button');
      deleteBtn.textContent = 'Hesap Sil';
      deleteBtn.addEventListener('click', () => {
        if (confirm(`"${user.username}" kullanıcısı silinsin mi?`)) {
          deleteUser(user._id);
        }
      });
      actionsTd.appendChild(deleteBtn);

      // Bakiye düzenleme butonu
      const editBalanceBtn = document.createElement('button');
      editBalanceBtn.textContent = 'Bakiye Düzenle';
      editBalanceBtn.addEventListener('click', () => {
        const newBalance = prompt('Yeni bakiye değerini girin:', user.balance || 0);
        if (newBalance !== null) {
          updateUserBalance(user._id, parseFloat(newBalance));
        }
      });
      actionsTd.appendChild(editBalanceBtn);

      tr.appendChild(actionsTd);
      userList.appendChild(tr);
    });
  }

  // Kullanıcı bakiyesini güncelle
  async function updateUserBalance(userId, newBalance) {
    try {
      const res = await fetch(`/admin/users/${userId}/update-balance`, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ balance: newBalance })
      });
      if (res.ok) {
        alert('Bakiye güncellendi');
        loadUsers();
      } else {
        alert('Bakiye güncellenirken hata oluştu');
      }
    } catch (error) {
      console.error('Bakiye güncelleme hatası:', error);
    }
  }

  // Arama fonksiyonu
  searchInput.addEventListener('input', async () => {
    const query = searchInput.value.toLowerCase();
    try {
      const res = await fetch('/admin/users');
      const users = await res.json();
      const filtered = users.filter(user =>
        (user.username && user.username.toLowerCase().includes(query)) ||
        (user.email && user.email.toLowerCase().includes(query))
      );
      displayUsers(filtered);
    } catch (error) {
      console.error('Arama sırasında hata:', error);
    }
  });

  // Sayfa yüklendiğinde tüm verileri çek
  loadUsers();
  showSection('sectionUsers');
  setActiveButton(btnUsers);
});
