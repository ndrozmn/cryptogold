document.addEventListener('DOMContentLoaded', () => {
  // Notification system
  class NotificationSystem {
    constructor() {
      this.notificationContainer = this.createNotificationContainer();
      this.notifications = [];
      this.checkPermission();
    }
    
    createNotificationContainer() {
      const container = document.createElement('div');
      container.id = 'notification-container';
      container.style.cssText = `
        position: fixed;
        top: 20px;
        right: 20px;
        z-index: 1000;
        width: 300px;
      `;
      document.body.appendChild(container);
      return container;
    }
    
    checkPermission() {
      if (!("Notification" in window)) {
        console.log("Bu tarayıcı bildirim desteği sunmuyor");
      } else if (Notification.permission === "granted") {
        // İzin zaten verilmiş
      } else if (Notification.permission !== "denied") {
        // İzin iste
        const requestPermissionButton = document.createElement('button');
        requestPermissionButton.textContent = 'Bildirimlere İzin Ver';
        requestPermissionButton.style.cssText = `
          position: fixed;
          bottom: 140px;
          right: 20px;
          background-color: #0f0f3f;
          color: #00ffe5;
          border: none;
          border-radius: 25px;
          padding: 10px 15px;
          font-size: 14px;
          cursor: pointer;
          z-index: 99;
          box-shadow: 0 0 10px #00ffe5;
        `;
        
        requestPermissionButton.addEventListener('click', () => {
          Notification.requestPermission().then(permission => {
            if (permission === "granted") {
              this.showNotification("Bildirimler", "Bildirimler başarıyla etkinleştirildi!");
              requestPermissionButton.remove();
            }
          });
        });
        
        document.body.appendChild(requestPermissionButton);
      }
    }
    
    showNotification(title, message, type = 'info') {
      // Tarayıcı bildirimi
      if (Notification.permission === "granted") {
        const notification = new Notification(title, {
          body: message,
          icon: '/favicon.ico'
        });
        
        notification.onclick = function() {
          window.focus();
          this.close();
        };
      }
      
      // Uygulama içi bildirim
      const notificationElement = document.createElement('div');
      notificationElement.className = `notification ${type}`;
      notificationElement.style.cssText = `
        background-color: var(--card-bg, #111);
        color: var(--text-color, #fff);
        border-left: 4px solid ${this.getColorByType(type)};
        border-radius: 4px;
        padding: 15px;
        margin-bottom: 10px;
        box-shadow: 0 2px 5px rgba(0,0,0,0.2);
        animation: slideIn 0.3s ease-out forwards;
        position: relative;
      `;
      
      const titleElement = document.createElement('h4');
      titleElement.textContent = title;
      titleElement.style.margin = '0 0 5px 0';
      
      const messageElement = document.createElement('p');
      messageElement.textContent = message;
      messageElement.style.margin = '0';
      
      const closeButton = document.createElement('button');
      closeButton.innerHTML = '&times;';
      closeButton.style.cssText = `
        position: absolute;
        top: 5px;
        right: 5px;
        background: none;
        border: none;
        color: var(--text-color, #fff);
        font-size: 18px;
        cursor: pointer;
      `;
      
      closeButton.addEventListener('click', () => {
        this.removeNotification(notificationElement);
      });
      
      notificationElement.appendChild(titleElement);
      notificationElement.appendChild(messageElement);
      notificationElement.appendChild(closeButton);
      
      this.notificationContainer.appendChild(notificationElement);
      this.notifications.push(notificationElement);
      
      // Otomatik kaldırma
      setTimeout(() => {
        if (this.notifications.includes(notificationElement)) {
          this.removeNotification(notificationElement);
        }
      }, 5000);
      
      // CSS animasyonu ekle
      const style = document.createElement('style');
      style.textContent = `
        @keyframes slideIn {
          from { transform: translateX(100%); opacity: 0; }
          to { transform: translateX(0); opacity: 1; }
        }
        
        @keyframes fadeOut {
          from { transform: translateX(0); opacity: 1; }
          to { transform: translateX(100%); opacity: 0; }
        }
      `;
      document.head.appendChild(style);
    }
    
    removeNotification(notificationElement) {
      notificationElement.style.animation = 'fadeOut 0.3s ease-in forwards';
      
      setTimeout(() => {
        if (this.notificationContainer.contains(notificationElement)) {
          this.notificationContainer.removeChild(notificationElement);
        }
        this.notifications = this.notifications.filter(n => n !== notificationElement);
      }, 300);
    }
    
    getColorByType(type) {
      switch(type) {
        case 'success': return '#4CAF50';
        case 'warning': return '#FF9800';
        case 'error': return '#F44336';
        case 'info':
        default: return '#00ffe5';
      }
    }
  }
  
  // Global erişim için
  window.notificationSystem = new NotificationSystem();
  
  // Test bildirimleri
  if (window.location.pathname === '/dashboard') {
    setTimeout(() => {
      window.notificationSystem.showNotification(
        "Hoş Geldiniz", 
        "Gold Yatırım paneline hoş geldiniz!", 
        "info"
      );
    }, 2000);
    
    // Yatırım bildirimi örneği
    if (document.querySelector('.investment-box')) {
      setTimeout(() => {
        window.notificationSystem.showNotification(
          "Yatırım Fırsatı", 
          "Yeni yatırım paketleri eklendi! Hemen inceleyin.", 
          "success"
        );
      }, 5000);
    }
  }
});
