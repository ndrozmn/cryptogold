const mongoose = require('mongoose');

const investmentSchema = new mongoose.Schema({
  user: { type: mongoose.Schema.Types.ObjectId, ref: 'User', required: true },
  usdtAmount: { type: Number, required: true },
  amount: { type: Number }, // Alternatif miktar alanı
  lockDays: { type: Number, enum: [7, 14, 21, 32], required: true },
  interestRate: { type: Number, required: true },
  startDate: { type: Date, default: Date.now },
  endDate: { type: Date, required: true },
  isActive: { type: Boolean, default: true },
  isPaid: { type: Boolean, default: false },
  status: { type: String, enum: ['pending', 'approved', 'rejected'], default: 'pending' },
  stockControl: { type: Number, default: 0 },
  price: { type: Number, default: 0 },
  earnings: { type: Number, default: 0 },
  percentage: { type: Number, default: 0 },
  name: { type: String }
});

module.exports = mongoose.model('Investment', investmentSchema);
