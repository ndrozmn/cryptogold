const mongoose = require('mongoose');

const depositSchema = new mongoose.Schema({
  user: {
    type: mongoose.Schema.Types.ObjectId,
    ref: 'User',
    required: true
  },
  amount: {
    type: Number,
    required: true,
    min: 0
  },
  tronTransactionId: {
    type: String,
    trim: true
  },
  status: {
    type: String,
    enum: ['pending', 'approved', 'rejected'],
    default: 'pending'
  },
  requestedAt: {
    type: Date,
    default: Date.now
  },
  processedAt: {
    type: Date
  },
  notes: {
    type: String,
    trim: true
  }
});

// Kullanıcı silindiğinde ilişkili para yatırma taleplerini de sil
depositSchema.pre('remove', { document: true, query: false }, async function(next) {
  try {
    const userId = this.user;
    await mongoose.model('Deposit').deleteMany({ user: userId });
    next();
  } catch (error) {
    next(error);
  }
});

module.exports = mongoose.model('Deposit', depositSchema);
