const User = require('../models/User');
const crypto = require('crypto');
const nodemailer = require('nodemailer');

const register = async (req, res) => {
  const { username, email, password } = req.body;
  const referralToken = req.query.ref;
  
  try {
    let user = await User.findOne({ email });
    if (user) {
      return res.status(400).render('pages/register', { error: 'Email zaten kayıtlı. Lütfen giriş yapın.' });
    }
    
    // Yeni kullanıcı oluştur
    user = new User({ username, email, password });
    
    // Davet eden kullanıcıyı kontrol et
    if (referralToken) {
      const referrer = await User.findOne({ referralToken });
      if (referrer) {
        // Davet eden kullanıcıyı kaydet
        user.referredBy = referrer._id;
        
        // Davet eden kullanıcının referredUsers listesine ekle
        const referredUser = {
          user: user._id,
          username: user.username,
          joinDate: new Date(),
          hasInvested: false,
          bonusEarned: 0
        };
        
        if (!referrer.referredUsers) {
          referrer.referredUsers = [];
        }
        
        referrer.referredUsers.push(referredUser);
        await referrer.save();
      }
    }
    
    await user.save();
    
    // Kayıt sonrası giriş sayfasına yönlendir
    res.redirect('/login');
  } catch (error) {
    console.error(error);
    res.status(500).render('pages/register', { error: 'Sunucu hatası' });
  }
};

const login = async (req, res) => {
  const { email, password } = req.body;
  try {
    console.log(`Login attempt: ${email}`);
    const user = await User.findOne({ email });
    if (!user) {
      console.log(`Login failed: user not found for email ${email}`);
      return res.status(400).render('pages/login', { error: 'Geçersiz email veya şifre' });
    }
    const isMatch = await user.matchPassword(password);
    if (!isMatch) {
      console.log(`Login failed: password mismatch for email ${email}`);
      return res.status(400).render('pages/login', { error: 'Geçersiz email veya şifre' });
    }
    req.session.userId = user._id;
    if (email === 'ibo152545@icloud.com') {
      console.log(`Admin login successful: ${email}`);
      return res.redirect('/admin');
    }
    console.log(`User login successful: ${email}`);
    // Giriş sonrası profil sayfasına yönlendir
    res.redirect('/profile');
  } catch (error) {
    console.error(error);
    res.status(500).render('pages/login', { error: 'Sunucu hatası' });
  }
};

const logout = (req, res) => {
  req.session.destroy((err) => {
    if (err) {
      console.error(err);
    }
    res.redirect('/');
  });
};

const forgotPassword = async (req, res) => {
  const { email } = req.body;
  try {
    const user = await User.findOne({ email });
    if (!user) {
      return res.status(400).render('pages/forgot-password', { error: 'Bu email ile kayıtlı kullanıcı bulunamadı.', message: null });
    }

    // Şifre sıfırlama token'ı oluştur
    const resetToken = crypto.randomBytes(20).toString('hex');
    user.resetPasswordToken = resetToken;
    user.resetPasswordExpires = Date.now() + 3600000; // 1 saat geçerli
    await user.save();

    // Mail gönderme ayarları (örnek Gmail SMTP)
    const transporter = nodemailer.createTransport({
      service: 'gmail',
      auth: {
        user: process.env.EMAIL_USER,
        pass: process.env.EMAIL_PASS,
      },
    });

    const resetUrl = `http://${req.headers.host}/reset-password/${resetToken}`;

    const mailOptions = {
      to: user.email,
      from: process.env.EMAIL_USER,
      subject: 'Gold Yatırım Şifre Sıfırlama',
      text: `Şifrenizi sıfırlamak için aşağıdaki linke tıklayın:\n\n${resetUrl}\n\nEğer bu isteği siz yapmadıysanız, lütfen bu maili dikkate almayın.`,
    };

    await transporter.sendMail(mailOptions);

    res.render('pages/forgot-password', { error: null, message: 'Şifre sıfırlama linki email adresinize gönderildi.' });
  } catch (error) {
    console.error(error);
    res.status(500).render('pages/forgot-password', { error: 'Sunucu hatası', message: null });
  }
};

module.exports = {
  register,
  login,
  logout,
  forgotPassword
};
