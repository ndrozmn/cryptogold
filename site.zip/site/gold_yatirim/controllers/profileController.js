
const User = require('../models/User');
const Investment = require('../models/Investment');
const Withdrawal = require('../models/Withdrawal');
const Deposit = require('../models/Deposit');
const crypto = require('crypto');

// TRON cüzdan adresi (örnek, gerçek uygulamada güvenli bir şekilde saklanmalı)
const TRON_WALLET_ADDRESS = 'TRX1234567890ABCDEFGHIJKLMNOPQRSTUVWXYZ';

exports.getProfile = async (req, res) => {
  try {
    const user = await User.findById(req.user._id)
      .populate({
        path: 'referredUsers.user',
        select: 'username createdAt'
      });
    
    if (!user) {
      console.error('Kullanıcı bulunamadı:', req.user._id);
      return res.status(404).send('Kullanıcı bulunamadı');
    }
    
    // Aktif ve geçmiş yatırımları ayrı ayrı al
    const activeInvestments = await Investment.find({ 
      user: req.user._id,
      isActive: true 
    });
    
    const pastInvestments = await Investment.find({ 
      user: req.user._id,
      isActive: false 
    });
    
    if (!user.referralLink) {
      const referralToken = crypto.randomBytes(20).toString('hex');
      const referralLink = `${req.protocol}://${req.get('host')}/register?ref=${referralToken}`;
      await User.findByIdAndUpdate(user._id, { referralToken, referralLink });
      user.referralLink = referralLink;
    }
    
    res.render('pages/profile', {
      user,
      activeInvestments,
      pastInvestments,
      referralCode: user.referralLink || 'YOK',
      referralEarnings: user.referralEarnings || 0
    });
  } catch (error) {
    console.error('Profil bilgileri alınırken hata:', error);
    console.error(error.stack);
    res.status(500).send('Profil bilgileri alınırken hata oluştu');
  }
};

// Profil verilerini JSON olarak dönen API
exports.getProfileData = async (req, res) => {
  try {
    const user = await User.findById(req.user._id);
    
    // Aktif ve geçmiş yatırımları ayrı ayrı al
    const activeInvestments = await Investment.find({ 
      user: req.user._id,
      isActive: true 
    });
    
    const pastInvestments = await Investment.find({ 
      user: req.user._id,
      isActive: false 
    });
    
    // Davet edilen kullanıcıları al
    const referredUsers = user.referredUsers || [];
    
    res.json({
      balance: user.balance || 0,
      referralLink: user.referralLink || 'YOK',
      referralEarnings: user.referralEarnings || 0,
      tronWalletAddress: user.tronWalletAddress || '',
      activeInvestments,
      pastInvestments,
      referredUsers
    });
  } catch (error) {
    res.status(500).json({ error: 'Profil verileri alınırken hata oluştu' });
  }
};

// TRON cüzdan adresi kaydetme
exports.saveTronWalletAddress = async (req, res) => {
  try {
    const { tronWalletAddress } = req.body;
    
    if (!tronWalletAddress || tronWalletAddress.trim() === '') {
      return res.status(400).json({ error: 'Geçerli bir TRON cüzdan adresi giriniz' });
    }
    
    await User.findByIdAndUpdate(req.user._id, { tronWalletAddress });
    
    res.json({ 
      message: 'TRON cüzdan adresi başarıyla kaydedildi', 
      tronWalletAddress 
    });
  } catch (error) {
    console.error('TRON cüzdan adresi kaydedilirken hata:', error);
    res.status(500).json({ error: 'TRON cüzdan adresi kaydedilemedi' });
  }
};

// Para yatırma talebi oluşturma
exports.createDepositRequest = async (req, res) => {
  try {
    const { amount } = req.body;
    
    if (!amount || isNaN(amount) || Number(amount) <= 0) {
      return res.status(400).json({ error: 'Geçerli bir miktar giriniz' });
    }
    
    const deposit = new Deposit({
      user: req.user._id,
      amount: Number(amount),
      status: 'pending'
    });
    
    await deposit.save();
    
    res.json({ 
      message: 'Para yatırma talebi oluşturuldu', 
      depositId: deposit._id,
      tronWalletAddress: TRON_WALLET_ADDRESS
    });
  } catch (error) {
    console.error('Para yatırma talebi oluşturulurken hata:', error);
    res.status(500).json({ error: 'Para yatırma talebi oluşturulamadı' });
  }
};

// Para yatırma talebini onaylama (kullanıcı tarafından)
exports.confirmDeposit = async (req, res) => {
  try {
    const { depositId, tronTransactionId } = req.body;
    
    if (!depositId || !tronTransactionId) {
      return res.status(400).json({ error: 'Geçersiz talep' });
    }
    
    const deposit = await Deposit.findOne({ 
      _id: depositId,
      user: req.user._id
    });
    
    if (!deposit) {
      return res.status(404).json({ error: 'Para yatırma talebi bulunamadı' });
    }
    
    deposit.tronTransactionId = tronTransactionId;
    await deposit.save();
    
    res.json({ 
      message: 'Para yatırma talebi onaylandı. Admin onayı bekleniyor.',
      deposit
    });
  } catch (error) {
    console.error('Para yatırma talebi onaylanırken hata:', error);
    res.status(500).json({ error: 'Para yatırma talebi onaylanamadı' });
  }
};

// Para çekme talebi oluşturma
exports.createWithdrawalRequest = async (req, res) => {
  try {
    const { amount, tronWalletAddress } = req.body;
    const amountNum = Number(amount);
    
    if (!amount || isNaN(amountNum) || amountNum <= 0) {
      return res.status(400).json({ error: 'Geçerli bir miktar giriniz' });
    }
    
    if (!tronWalletAddress || tronWalletAddress.trim() === '') {
      return res.status(400).json({ error: 'Geçerli bir TRON cüzdan adresi giriniz' });
    }
    
    const user = await User.findById(req.user._id);
    
    if ((user.balance || 0) < amountNum) {
      return res.status(400).json({ error: 'Yetersiz bakiye' });
    }
    
    // %5 komisyon hesaplama
    const fee = amountNum * 0.05;
    const netAmount = amountNum - fee;
    
    const withdrawal = new Withdrawal({
      user: req.user._id,
      amount: amountNum,
      fee,
      netAmount,
      tronWalletAddress,
      status: 'pending'
    });
    
    await withdrawal.save();
    
    // Kullanıcı bakiyesinden düş
    user.balance -= amountNum;
    await user.save();
    
    res.json({ 
      message: 'Para çekme talebi oluşturuldu', 
      withdrawal,
      balance: user.balance
    });
  } catch (error) {
    console.error('Para çekme talebi oluşturulurken hata:', error);
    res.status(500).json({ error: 'Para çekme talebi oluşturulamadı' });
  }
};

// Davet bağlantısı oluşturma
exports.generateReferralLink = async (req, res) => {
  try {
    const user = await User.findById(req.user._id);
    if (!user) {
      return res.status(404).json({ error: 'Kullanıcı bulunamadı' });
    }
    
    // Eğer kullanıcıda referralToken yoksa oluştur
    if (!user.referralToken) {
      const referralToken = crypto.randomBytes(20).toString('hex');
      user.referralToken = referralToken;
    }
    
    const referralLink = `${req.protocol}://${req.get('host')}/register?ref=${user.referralToken}`;
    user.referralLink = referralLink;
    await user.save();
    
    res.json({ referralLink });
  } catch (error) {
    console.error('Davet bağlantısı oluşturulurken hata:', error);
    res.status(500).json({ error: 'Davet bağlantısı oluşturulamadı' });
  }
};

// Davet edilen kullanıcıları getirme
exports.getReferredUsers = async (req, res) => {
  try {
    const user = await User.findById(req.user._id)
      .populate({
        path: 'referredUsers.user',
        select: 'username email createdAt'
      });
    
    if (!user) {
      return res.status(404).json({ error: 'Kullanıcı bulunamadı' });
    }
    
    res.json({ 
      referredUsers: user.referredUsers || [],
      referralEarnings: user.referralEarnings || 0
    });
  } catch (error) {
    console.error('Davet edilen kullanıcılar alınırken hata:', error);
    res.status(500).json({ error: 'Davet edilen kullanıcılar alınamadı' });
  }
};

// Para yatırma geçmişini getirme
exports.getDeposits = async (req, res) => {
  try {
    const deposits = await Deposit.find({ user: req.user._id })
      .sort({ createdAt: -1 });
    
    res.json({ deposits });
  } catch (error) {
    console.error('Para yatırma geçmişi alınırken hata:', error);
    res.status(500).json({ error: 'Para yatırma geçmişi alınamadı' });
  }
};

// Para çekme geçmişini getirme
exports.getWithdrawals = async (req, res) => {
  try {
    const withdrawals = await Withdrawal.find({ user: req.user._id })
      .sort({ createdAt: -1 });
    
    res.json({ withdrawals });
  } catch (error) {
    console.error('Para çekme geçmişi alınırken hata:', error);
    res.status(500).json({ error: 'Para çekme geçmişi alınamadı' });
  }
};

// Bekleyen işlemleri getirme
exports.getPendingTransactions = async (req, res) => {
  try {
    const pendingDeposits = await Deposit.find({ 
      user: req.user._id,
      status: 'pending'
    }).sort({ createdAt: -1 });
    
    const pendingWithdrawals = await Withdrawal.find({ 
      user: req.user._id,
      status: 'pending'
    }).sort({ createdAt: -1 });
    
    const pendingInvestments = await Investment.find({ 
      user: req.user._id,
      status: 'pending'
    }).sort({ createdAt: -1 });
    
    res.json({
      pendingDeposits,
      pendingWithdrawals,
      pendingInvestments
    });
  } catch (error) {
    console.error('Bekleyen işlemler alınırken hata:', error);
    res.status(500).json({ error: 'Bekleyen işlemler alınamadı' });
  }
};
