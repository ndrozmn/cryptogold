exports.dashboard = (req, res) => {
  const userId = req.session.userId;
  res.render('pages/dashboard', { title: 'Dashboard', userId });
};
