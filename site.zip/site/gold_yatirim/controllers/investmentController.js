
const Investment = require('../models/Investment');
const User = require('../models/User');

// Yatırım seçenekleri için global değişken
let investmentOptions = [
  { id: 1, name: 'Altın Paket 1', price: 10, stockControl: 10, earnings: 7 },
  { id: 2, name: 'Altın Paket 2', price: 25, stockControl: 10, earnings: 7 },
  { id: 3, name: 'Altın Paket 3', price: 59, stockControl: 10, earnings: 7 },
  { id: 4, name: 'Altın Paket 4', price: 84, stockControl: 10, earnings: 7 },
  { id: 5, name: 'Altın Paket 5', price: 99, stockControl: 10, earnings: 7 },
  { id: 6, name: 'Altın Paket 6', price: 120, stockControl: 10, earnings: 7 },
  { id: 7, name: 'Altın Paket 7', price: 190, stockControl: 10, earnings: 7 },
  { id: 8, name: 'Altın Paket 8', price: 250, stockControl: 10, earnings: 7 },
  { id: 9, name: 'Altın Paket 9', price: 300, stockControl: 10, earnings: 7 },
  { id: 10, name: 'Altın Paket 10', price: 500, stockControl: 10, earnings: 7 },
  { id: 11, name: 'Altın Paket 11', price: 750, stockControl: 10, earnings: 7 },
  { id: 12, name: 'Altın Paket 12', price: 1000, stockControl: 10, earnings: 7 },
  { id: 13, name: 'Altın Paket 13', price: 1500, stockControl: 10, earnings: 7 },
  { id: 14, name: 'Altın Paket 14', price: 2500, stockControl: 10, earnings: 7 },
  { id: 15, name: 'Altın Paket 15', price: 5000, stockControl: 10, earnings: 7 },
  { id: 16, name: 'Altın Paket 16', price: 7500, stockControl: 10, earnings: 7 },
  { id: 17, name: 'Altın Paket 17', price: 10000, stockControl: 10, earnings: 7 },
  { id: 18, name: 'Altın Paket 18', price: 15000, stockControl: 10, earnings: 7 },
  { id: 19, name: 'Altın Paket 19', price: 50000, stockControl: 10, earnings: 7 },
  { id: 20, name: 'Altın Paket 20', price: 90000, stockControl: 10, earnings: 7 },
  { id: 21, name: 'Altın Paket 21', price: 25000, stockControl: 10, earnings: 7 },
  { id: 22, name: 'Altın Paket 22', price: 500000, stockControl: 10, earnings: 7 },
  { id: 23, name: 'Altın Paket 23', price: 5000000, stockControl: 10, earnings: 7 },
  { id: 24, name: 'Altın Paket 24', price: 29999999, stockControl: 10, earnings: 7 },
  { id: 25, name: 'Altın Paket 25', price: 50000000, stockControl: 10, earnings: 7 },
];

// Tüm yatırım seçeneklerini getirme
exports.getAllInvestmentOptions = async (req, res) => {
  try {
    res.status(200).json(investmentOptions);
  } catch (error) {
    console.error('Yatırım seçenekleri alınırken hata:', error);
    res.status(500).json({ error: 'Yatırım seçenekleri alınamadı' });
  }
};

// Yatırım seçeneğini güncelleme
exports.updateInvestmentOption = async (id, data) => {
  try {
    const index = investmentOptions.findIndex(option => option.id === parseInt(id, 10));
    if (index !== -1) {
      investmentOptions[index] = { ...investmentOptions[index], ...data };
      return true;
    }
    return false;
  } catch (error) {
    console.error('Yatırım seçeneği güncellenirken hata:', error);
    return false;
  }
};

// Yeni yatırım oluşturma
exports.createInvestment = async (req, res) => {
  try {
    const { investmentId, usdtAmount, lockDays } = req.body;
    const user = await User.findById(req.user._id);
    
    // Kullanıcının bakiyesini kontrol et
    if ((user.balance || 0) < usdtAmount) {
      return res.status(400).json({ error: 'Yetersiz bakiye' });
    }
    
    // Yatırım seçeneğini bul
    const investmentOption = investmentOptions.find(option => option.id === investmentId);
    if (!investmentOption) {
      return res.status(404).json({ error: 'Yatırım seçeneği bulunamadı' });
    }
    
    // Stok kontrolü
    if (investmentOption.stockControl <= 0) {
      return res.status(400).json({ error: 'Bu yatırım paketi stokta kalmamıştır' });
    }
    
    // Stok sayısını azalt
    investmentOption.stockControl -= 1;
    
    const interestRates = {7: 7, 14: 13, 21: 20, 32: 30};
    const interestRate = interestRates[lockDays];
    const startDate = new Date();
    const endDate = new Date(startDate.getTime() + lockDays * 24 * 60 * 60 * 1000);

    const investment = new Investment({
      user: req.user._id,
      usdtAmount,
      lockDays,
      interestRate,
      startDate,
      endDate,
      isActive: true,
      isPaid: false,
      status: 'approved',
      name: `Altın Paket ${investmentId}`
    });

    await investment.save();
    
    // Kullanıcının bakiyesinden düş
    user.balance -= usdtAmount;
    await user.save();
    
    // Eğer bu kullanıcı bir referans ile kaydolduysa ve ilk yatırımını yapıyorsa
    // davet eden kullanıcıya bonus ekle
    const firstInvestment = await Investment.countDocuments({ user: req.user._id }) === 1;
    
    if (firstInvestment && user.referredBy) {
      const referrer = await User.findById(user.referredBy);
      if (referrer) {
        // Davet eden kullanıcıya %20 bonus ekle
        const bonusAmount = usdtAmount * 0.2;
        referrer.balance = (referrer.balance || 0) + bonusAmount;
        referrer.referralEarnings = (referrer.referralEarnings || 0) + bonusAmount;
        
        // Davet edilen kullanıcının durumunu güncelle
        const referredUserIndex = referrer.referredUsers.findIndex(
          ru => ru.user.toString() === req.user._id.toString()
        );
        
        if (referredUserIndex !== -1) {
          referrer.referredUsers[referredUserIndex].hasInvested = true;
          referrer.referredUsers[referredUserIndex].bonusEarned = bonusAmount;
        }
        
        await referrer.save();
      }
    }

    res.status(201).json({ 
      message: 'Yatırım başarıyla oluşturuldu', 
      investment,
      balance: user.balance
    });
  } catch (error) {
    console.error('Yatırım oluşturulurken hata:', error);
    res.status(500).json({ error: 'Yatırım oluşturulurken hata oluştu' });
  }
};

// Kullanıcının yatırımlarını listeleme
exports.getUserInvestments = async (req, res) => {
  try {
    const activeInvestments = await Investment.find({ 
      user: req.user._id,
      isActive: true 
    });
    
    const pastInvestments = await Investment.find({ 
      user: req.user._id,
      isActive: false 
    });
    
    res.status(200).json({ activeInvestments, pastInvestments });
  } catch (error) {
    console.error('Yatırımlar getirilirken hata:', error);
    res.status(500).json({ error: 'Yatırımlar getirilirken hata oluştu' });
  }
};

// Yatırım sayfasını render etme
exports.renderInvestmentPage = (req, res) => {
  if (req.session && req.session.userId) {
    res.render('pages/investment');
  } else {
    res.render('pages/investment_guest');
  }
};

// Geri sayım bittiğinde yatırımın durumunu güncelleme ve faiz ekleme
exports.processInvestmentMaturity = async (investmentId) => {
  try {
    const investment = await Investment.findById(investmentId).populate('user');
    if (!investment || !investment.isActive) return;

    const now = new Date();
    if (now >= investment.endDate && !investment.isPaid) {
      // Faiz hesaplama
      const profit = (investment.usdtAmount * investment.interestRate) / 100;
      investment.isActive = false;
      investment.isPaid = true;
      investment.earnings = profit;
      await investment.save();

      // Kullanıcının bakiye güncellemesi
      investment.user.balance = (investment.user.balance || 0) + investment.usdtAmount + profit;
      await investment.user.save();

      console.log(`Yatırım vadesi doldu: ${investmentId}, Kullanıcı: ${investment.user._id}, Kazanç: ${profit}`);
    }
  } catch (error) {
    console.error('Yatırım vadesi işlenirken hata:', error);
  }
};

// Tüm aktif yatırımları kontrol et ve vadesi dolmuş olanları işle
exports.checkAllInvestments = async () => {
  try {
    const now = new Date();
    const activeInvestments = await Investment.find({ 
      isActive: true,
      endDate: { $lte: now },
      isPaid: false
    });
    
    console.log(`${activeInvestments.length} adet vadesi dolmuş yatırım bulundu.`);
    
    for (const investment of activeInvestments) {
      await exports.processInvestmentMaturity(investment._id);
    }
  } catch (error) {
    console.error('Yatırımlar kontrol edilirken hata:', error);
  }
};
