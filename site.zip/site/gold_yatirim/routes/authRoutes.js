const express = require('express');
const router = express.Router();
const authController = require('../controllers/authController');

router.get('/login', (req, res) => {
  res.render('pages/login', { error: null });
});

router.post('/login', authController.login);

router.get('/register', (req, res) => {
  res.render('pages/register', { error: null });
});

router.post('/register', authController.register);

router.get('/logout', authController.logout);

// Şifre unutma sayfası
router.get('/forgot-password', (req, res) => {
  res.render('pages/forgot-password', { error: null, message: null });
});

// Şifre sıfırlama isteği
router.post('/forgot-password', authController.forgotPassword);

module.exports = router;
