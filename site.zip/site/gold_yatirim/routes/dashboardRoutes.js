const express = require('express');
const router = express.Router();
const dashboardController = require('../controllers/dashboardController');
const { ensureAuth } = require('../middleware/authMiddleware');

router.get('/dashboard', ensureAuth, dashboardController.dashboard);

module.exports = router;
