const express = require('express');
const router = express.Router();
const profileController = require('../controllers/profileController');
const authMiddleware = require('../middleware/authMiddleware');

// Profil sayfası
router.get('/', authMiddleware.ensureAuth, profileController.getProfile);

// Profil verilerini JSON olarak dönen API
router.get('/data', authMiddleware.ensureAuth, profileController.getProfileData);

// TRON cüzdan adresi kaydetme
router.post('/save-tron-wallet', authMiddleware.ensureAuth, profileController.saveTronWalletAddress);

// Para yatırma talebi oluşturma
router.post('/create-deposit', authMiddleware.ensureAuth, profileController.createDepositRequest);

// Para yatırma talebini onaylama (kullanıcı tarafından)
router.post('/confirm-deposit', authMiddleware.ensureAuth, profileController.confirmDeposit);

// Para çekme talebi oluşturma
router.post('/create-withdrawal', authMiddleware.ensureAuth, profileController.createWithdrawalRequest);

// Davet bağlantısı oluşturma
router.get('/referral-link', authMiddleware.ensureAuth, profileController.generateReferralLink);

// Davet edilen kullanıcıları getirme
router.get('/referred-users', authMiddleware.ensureAuth, profileController.getReferredUsers);

// Para yatırma geçmişini getirme
router.get('/deposits', authMiddleware.ensureAuth, profileController.getDeposits);

// Para çekme geçmişini getirme
router.get('/withdrawals', authMiddleware.ensureAuth, profileController.getWithdrawals);

// Bekleyen işlemleri getirme
router.get('/pending-transactions', authMiddleware.ensureAuth, profileController.getPendingTransactions);

module.exports = router;
