const express = require('express');
const router = express.Router();

const ADMIN_USERNAME = 'ibo152545@icloud.com';
const ADMIN_PASSWORD = 'Az141414';

function authMiddleware(req, res, next) {
  console.log('authMiddleware çalıştı');
  if (req.session && req.session.userId) {
    const User = require('../models/User');
    User.findById(req.session.userId)
      .then(user => {
        console.log('Kullanıcı bulundu:', user ? user.email : 'null');
        if (user && user.email.toLowerCase() === ADMIN_USERNAME.toLowerCase()) {
          console.log('Admin doğrulandı');
          next();
        } else {
          console.log('Admin değil, ana sayfaya yönlendiriliyor');
          res.redirect('/');
        }
      })
      .catch(err => {
        console.error('Hata:', err);
        res.redirect('/');
      });
  } else {
    console.log('Oturum yok, login sayfasına yönlendiriliyor');
    res.redirect('/login');
  }
}

router.get('/', authMiddleware, (req, res) => {
  console.log('Admin sayfası render ediliyor');
  res.render('pages/admin');
});

// Tüm kullanıcıları listeleyen endpoint
router.get('/users', authMiddleware, async (req, res) => {
  console.log('GET /admin/users isteği alındı');
  const User = require('../models/User');
  try {
    const users = await User.find({}, 'username email balance referralToken referralLink');
    res.json(users);
  } catch (error) {
    console.error('Kullanıcılar alınırken hata:', error);
    res.status(500).json({ error: 'Kullanıcılar alınamadı' });
  }
});

// Kullanıcı silme endpointi
router.delete('/users/:id', authMiddleware, async (req, res) => {
  const User = require('../models/User');
  try {
    const user = await User.findByIdAndDelete(req.params.id);
    if (!user) {
      return res.status(404).json({ error: 'Kullanıcı bulunamadı' });
    }
    res.json({ message: 'Kullanıcı silindi' });
  } catch (error) {
    console.error('Kullanıcı silinirken hata:', error);
    res.status(500).json({ error: 'Kullanıcı silinemedi' });
  }
});

// Şifre sıfırlama endpointi
router.post('/users/:id/reset-password', authMiddleware, async (req, res) => {
  const User = require('../models/User');
  try {
    const user = await User.findById(req.params.id);
    if (!user) {
      return res.status(404).json({ error: 'Kullanıcı bulunamadı' });
    }
    user.password = '123456';
    await user.save();
    res.json({ message: 'Şifre sıfırlandı' });
  } catch (error) {
    console.error('Şifre sıfırlama hatası:', error);
    res.status(500).json({ error: 'Şifre sıfırlanamadı' });
  }
});

// Kullanıcı bakiyesini güncelleme endpointi
router.post('/users/:id/update-balance', authMiddleware, async (req, res) => {
  const User = require('../models/User');
  try {
    const user = await User.findById(req.params.id);
    if (!user) {
      return res.status(404).json({ error: 'Kullanıcı bulunamadı' });
    }
    user.balance = req.body.balance;
    await user.save();
    res.json({ message: 'Bakiye güncellendi', balance: user.balance });
  } catch (error) {
    console.error('Bakiye güncelleme hatası:', error);
    res.status(500).json({ error: 'Bakiye güncellenemedi' });
  }
});

// Yatırım taleplerini listeleyen endpoint
router.get('/investment-requests', authMiddleware, async (req, res) => {
  const Investment = require('../models/Investment');
  try {
    const requests = await Investment.find({ status: 'pending' });
    res.json(requests);
  } catch (error) {
    console.error('Yatırım talepleri alınırken hata:', error);
    res.status(500).json({ error: 'Yatırım talepleri alınamadı' });
  }
});

// Çekim taleplerini listeleyen endpoint
router.get('/withdrawal-requests', authMiddleware, async (req, res) => {
  const Withdrawal = require('../models/Withdrawal');
  try {
    const requests = await Withdrawal.find({ status: 'pending' })
      .populate('user', 'username email');
    res.json(requests);
  } catch (error) {
    console.error('Çekim talepleri alınırken hata:', error);
    res.status(500).json({ error: 'Çekim talepleri alınamadı' });
  }
});

// Para yatırma taleplerini listeleyen endpoint
router.get('/deposit-requests', authMiddleware, async (req, res) => {
  const Deposit = require('../models/Deposit');
  try {
    const requests = await Deposit.find({ status: 'pending' })
      .populate('user', 'username email');
    res.json(requests);
  } catch (error) {
    console.error('Para yatırma talepleri alınırken hata:', error);
    res.status(500).json({ error: 'Para yatırma talepleri alınamadı' });
  }
});

// Para yatırma talebini onaylayan endpoint
router.post('/deposit-requests/:id/approve', authMiddleware, async (req, res) => {
  const Deposit = require('../models/Deposit');
  const User = require('../models/User');
  try {
    const deposit = await Deposit.findById(req.params.id);
    if (!deposit) {
      return res.status(404).json({ error: 'Para yatırma talebi bulunamadı' });
    }
    
    deposit.status = 'approved';
    deposit.processedAt = new Date();
    await deposit.save();
    
    // Kullanıcı bakiyesini güncelle
    const user = await User.findById(deposit.user);
    if (user) {
      user.balance = (user.balance || 0) + deposit.amount;
      await user.save();
    }
    
    res.json({ message: 'Para yatırma talebi onaylandı' });
  } catch (error) {
    console.error('Para yatırma talebi onaylanırken hata:', error);
    res.status(500).json({ error: 'Para yatırma talebi onaylanamadı' });
  }
});

// Para yatırma talebini reddeden endpoint
router.post('/deposit-requests/:id/reject', authMiddleware, async (req, res) => {
  const Deposit = require('../models/Deposit');
  try {
    const deposit = await Deposit.findById(req.params.id);
    if (!deposit) {
      return res.status(404).json({ error: 'Para yatırma talebi bulunamadı' });
    }
    
    deposit.status = 'rejected';
    deposit.processedAt = new Date();
    deposit.notes = req.body.notes || 'Talep reddedildi';
    await deposit.save();
    
    res.json({ message: 'Para yatırma talebi reddedildi' });
  } catch (error) {
    console.error('Para yatırma talebi reddedilirken hata:', error);
    res.status(500).json({ error: 'Para yatırma talebi reddedilemedi' });
  }
});

// Yatırım talebini onaylayan endpoint
router.post('/investment-requests/:id/approve', authMiddleware, async (req, res) => {
  const Investment = require('../models/Investment');
  const User = require('../models/User');
  try {
    const investment = await Investment.findById(req.params.id);
    if (!investment) {
      return res.status(404).json({ error: 'Yatırım talebi bulunamadı' });
    }
    investment.status = 'approved';
    await investment.save();

    const user = await User.findById(investment.user);
    if (user) {
      user.balance += investment.amount || investment.usdtAmount || 0;
      await user.save();
    }

    res.json({ message: 'Yatırım talebi onaylandı' });
  } catch (error) {
    console.error('Yatırım talebi onaylanırken hata:', error);
    res.status(500).json({ error: 'Yatırım talebi onaylanamadı' });
  }
});

// Yatırım ayarlarını güncelleme endpointi
router.post('/investment-requests/:id/update', authMiddleware, async (req, res) => {
  const Investment = require('../models/Investment');
  try {
    const investment = await Investment.findById(req.params.id);
    if (!investment) {
      return res.status(404).json({ error: 'Yatırım bulunamadı' });
    }
    const { stockControl, price, earnings, percentage } = req.body;
    if (stockControl !== undefined) investment.stockControl = stockControl;
    if (price !== undefined) investment.price = price;
    if (earnings !== undefined) investment.earnings = earnings;
    if (percentage !== undefined) investment.percentage = percentage;
    await investment.save();
    res.json({ message: 'Yatırım ayarları güncellendi' });
  } catch (error) {
    console.error('Yatırım ayarları güncellenirken hata:', error);
    res.status(500).json({ error: 'Yatırım ayarları güncellenemedi' });
  }
});

// Yatırım ayarlarını listeleyen endpoint
router.get('/investment-settings', authMiddleware, async (req, res) => {
  const Investment = require('../models/Investment');
  try {
    const investments = await Investment.find({});
    res.json(investments);
  } catch (error) {
    console.error('Yatırım ayarları alınırken hata:', error);
    res.status(500).json({ error: 'Yatırım ayarları alınamadı' });
  }
});

// Yatırım seçeneklerini listeleyen endpoint
router.get('/investment-options', authMiddleware, async (req, res) => {
  try {
    // Yatırım seçeneklerini veritabanından al veya statik olarak tanımla
    const investmentOptions = [
      { id: 1, name: 'Altın Paket 1', price: 10, stockControl: 10, percentage: 7 },
      { id: 2, name: 'Altın Paket 2', price: 25, stockControl: 10, percentage: 7 },
      { id: 3, name: 'Altın Paket 3', price: 59, stockControl: 10, percentage: 7 },
      { id: 4, name: 'Altın Paket 4', price: 84, stockControl: 10, percentage: 7 },
      { id: 5, name: 'Altın Paket 5', price: 99, stockControl: 10, percentage: 7 },
      { id: 6, name: 'Altın Paket 6', price: 120, stockControl: 10, percentage: 7 },
      { id: 7, name: 'Altın Paket 7', price: 190, stockControl: 10, percentage: 7 },
      { id: 8, name: 'Altın Paket 8', price: 250, stockControl: 10, percentage: 7 },
      { id: 9, name: 'Altın Paket 9', price: 300, stockControl: 10, percentage: 7 },
      { id: 10, name: 'Altın Paket 10', price: 500, stockControl: 10, percentage: 7 },
      { id: 11, name: 'Altın Paket 11', price: 750, stockControl: 10, percentage: 7 },
      { id: 12, name: 'Altın Paket 12', price: 1000, stockControl: 10, percentage: 7 },
      { id: 13, name: 'Altın Paket 13', price: 1500, stockControl: 10, percentage: 7 },
      { id: 14, name: 'Altın Paket 14', price: 2500, stockControl: 10, percentage: 7 },
      { id: 15, name: 'Altın Paket 15', price: 5000, stockControl: 10, percentage: 7 },
      { id: 16, name: 'Altın Paket 16', price: 7500, stockControl: 10, percentage: 7 },
      { id: 17, name: 'Altın Paket 17', price: 10000, stockControl: 10, percentage: 7 },
      { id: 18, name: 'Altın Paket 18', price: 15000, stockControl: 10, percentage: 7 },
      { id: 19, name: 'Altın Paket 19', price: 50000, stockControl: 10, percentage: 7 },
      { id: 20, name: 'Altın Paket 20', price: 90000, stockControl: 10, percentage: 7 },
      { id: 21, name: 'Altın Paket 21', price: 25000, stockControl: 10, percentage: 7 },
      { id: 22, name: 'Altın Paket 22', price: 500000, stockControl: 10, percentage: 7 },
      { id: 23, name: 'Altın Paket 23', price: 5000000, stockControl: 10, percentage: 7 },
      { id: 24, name: 'Altın Paket 24', price: 29999999, stockControl: 10, percentage: 7 },
      { id: 25, name: 'Altın Paket 25', price: 50000000, stockControl: 10, percentage: 7 },
    ];
    
    res.status(200).json(investmentOptions);
  } catch (error) {
    console.error('Yatırım seçenekleri alınırken hata:', error);
    res.status(500).json({ error: 'Yatırım seçenekleri alınamadı' });
  }
});

// Yatırım seçeneğini güncelleme endpoint'i
router.post('/investment-options/:id/update', authMiddleware, async (req, res) => {
  try {
    const { id } = req.params;
    const { stockControl, price, earnings, percentage } = req.body;
    
    const investmentController = require('../controllers/investmentController');
    const updated = await investmentController.updateInvestmentOption(id, {
      stockControl,
      price,
      earnings,
      percentage
    });
    
    if (updated) {
      res.json({ 
        message: 'Yatırım seçeneği güncellendi',
        option: {
          id,
          stockControl,
          price,
          earnings,
          percentage
        }
      });
    } else {
      res.status(404).json({ error: 'Yatırım seçeneği bulunamadı' });
    }
  } catch (error) {
    console.error('Yatırım seçeneği güncellenirken hata:', error);
    res.status(500).json({ error: 'Yatırım seçeneği güncellenemedi' });
  }
});

// Yatırım talebini reddeden endpoint
router.post('/investment-requests/:id/reject', authMiddleware, async (req, res) => {
  const Investment = require('../models/Investment');
  try {
    const investment = await Investment.findById(req.params.id);
    if (!investment) {
      return res.status(404).json({ error: 'Yatırım talebi bulunamadı' });
    }
    investment.status = 'rejected';
    investment.isActive = false;
    await investment.save();
    res.json({ message: 'Yatırım talebi reddedildi' });
  } catch (error) {
    console.error('Yatırım talebi reddedilirken hata:', error);
    res.status(500).json({ error: 'Yatırım talebi reddedilemedi' });
  }
});

// Çekim talebini onaylayan endpoint
router.post('/withdrawal-requests/:id/approve', authMiddleware, async (req, res) => {
  const Withdrawal = require('../models/Withdrawal');
  const User = require('../models/User');
  try {
    const withdrawal = await Withdrawal.findById(req.params.id);
    if (!withdrawal) {
      return res.status(404).json({ error: 'Çekim talebi bulunamadı' });
    }
    withdrawal.status = 'approved';
    await withdrawal.save();

    // Kullanıcı bakiyesini güncelle
    const user = await User.findById(withdrawal.user);
    if (user) {
      // Bakiyeden çekim miktarını düş
      user.balance = Math.max(0, user.balance - withdrawal.amount);
      await user.save();
    }

    res.json({ message: 'Çekim talebi onaylandı' });
  } catch (error) {
    console.error('Çekim talebi onaylanırken hata:', error);
    res.status(500).json({ error: 'Çekim talebi onaylanamadı' });
  }
});

// Çekim talebini reddeden endpoint
router.post('/withdrawal-requests/:id/reject', authMiddleware, async (req, res) => {
  const Withdrawal = require('../models/Withdrawal');
  try {
    const withdrawal = await Withdrawal.findById(req.params.id);
    if (!withdrawal) {
      return res.status(404).json({ error: 'Çekim talebi bulunamadı' });
    }
    withdrawal.status = 'rejected';
    await withdrawal.save();
    res.json({ message: 'Çekim talebi reddedildi' });
  } catch (error) {
    console.error('Çekim talebi reddedilirken hata:', error);
    res.status(500).json({ error: 'Çekim talebi reddedilemedi' });
  }
});

module.exports = router;
