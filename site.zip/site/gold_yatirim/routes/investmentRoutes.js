const express = require('express');
const router = express.Router();
const investmentController = require('../controllers/investmentController');
const authMiddleware = require('../middleware/authMiddleware');

// Yatırım sayfasını render etme
router.get('/', authMiddleware.ensureAuth, investmentController.renderInvestmentPage);

// Tüm yatırım seçeneklerini getirme
router.get('/options', investmentController.getAllInvestmentOptions);

// Yeni yatırım oluşturma
router.post('/create', authMiddleware.ensureAuth, investmentController.createInvestment);

// Kullanıcının yatırımlarını listeleme
router.get('/my-investments', authMiddleware.ensureAuth, investmentController.getUserInvestments);

// Yatırımları kontrol et ve vadesi dolmuş olanları işle (cron job için)
router.get('/check-investments', async (req, res) => {
  try {
    await investmentController.checkAllInvestments();
    res.status(200).json({ message: 'Yatırımlar kontrol edildi' });
  } catch (error) {
    console.error('Yatırımlar kontrol edilirken hata:', error);
    res.status(500).json({ error: 'Yatırımlar kontrol edilirken hata oluştu' });
  }
});

module.exports = router;
