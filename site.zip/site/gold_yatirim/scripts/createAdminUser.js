const mongoose = require('mongoose');
const User = require('../models/User');
require('dotenv').config();

async function createAdmin() {
  try {
    await mongoose.connect(process.env.MONGO_URI, {
      useNewUrlParser: true,
      useUnifiedTopology: true,
    });

    const existingAdmin = await User.findOne({ email: 'ibo152545@icloud.com' });
    if (existingAdmin) {
      console.log('Admin kullanıcı zaten mevcut.');
      process.exit(0);
    }

    const adminUser = new User({
      username: 'admin',
      email: 'ibo152545@icloud.com',
      password: 'Az141414',
      isAdmin: true,
    });

    await adminUser.save();
    console.log('Admin kullanıcı başarıyla oluşturuldu.');
    process.exit(0);
  } catch (error) {
    console.error('Admin kullanıcı oluşturulurken hata:', error);
    process.exit(1);
  }
}

createAdmin();
