const cron = require('node-cron');
const investmentController = require('../controllers/investmentController');
const axios = require('axios');

// Yatırımları kontrol etme işlemi - Her gün saat 00:00'da çalışır
const checkInvestmentsJob = cron.schedule('0 0 * * *', async () => {
  console.log('Yatırımlar kontrol ediliyor...');
  try {
    await investmentController.checkAllInvestments();
    console.log('Yatırım kontrolü tamamlandı.');
  } catch (error) {
    console.error('Yatırım kontrolü sırasında hata:', error);
  }
});

// Alternatif olarak, kendi sunucumuzda çalışan cron job yerine
// API endpoint'ini çağıran bir HTTP isteği de kullanılabilir
const checkInvestmentsViaAPI = async () => {
  try {
    const response = await axios.get('http://localhost:3000/investments/check-investments');
    console.log('API yanıtı:', response.data);
  } catch (error) {
    console.error('API isteği sırasında hata:', error);
  }
};

// Tüm cron işlerini başlat
const startCronJobs = () => {
  checkInvestmentsJob.start();
  console.log('Cron işleri başlatıldı.');
};

// Tüm cron işlerini durdur
const stopCronJobs = () => {
  checkInvestmentsJob.stop();
  console.log('Cron işleri durduruldu.');
};

module.exports = {
  startCronJobs,
  stopCronJobs,
  checkInvestmentsViaAPI
};
