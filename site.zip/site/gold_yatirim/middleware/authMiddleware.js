exports.ensureAuth = (req, res, next) => {
  if (req.session && req.session.userId) {
    req.user = { _id: req.session.userId }; // req.user objesi ekleniyor
    return next();
  } else {
    res.redirect('/login');
  }
};
